<?php 
  include("includes/config.php");
  $event_id=$_GET['id'];

  ////for fetch event name from get id///////
  $select="select event_name from event_detail where id='$event_id'";
  $run = $GLOBALS['db']->prepare($select);
  $run->execute();
  $fetch_res=$run->fetch(PDO::FETCH_ASSOC);
  

  $valid_formats = array("jpg", "png", "gif", "zip", "bmp");
  $max_file_size = 1024*100; //100 kb
  $path = "images/"; // Upload directory
  $count = 0;

  if(isset($_REQUEST['submit']))
  {
     $event_id=$_POST['event_id'];
     //print_r($_FILES['image_path']['name']);
     //die();
       
    // Loop $_FILES to exeicute all files
  foreach ($_FILES['image_path']['name'] as $f => $image_path) 
  {     
      if ($_FILES['image_path']['error'][$f] == 4) 
      {
          continue; // Skip file if any error found
      }        
      if ($_FILES['image_path']['error'][$f] == 0) 
      {            
          if ($_FILES['image_path']['size'][$f] > $max_file_size)
           {
              $message[] = "$name is too large!.";
              continue; // Skip large files
           }
          
          elseif( ! in_array(pathinfo($image_path, PATHINFO_EXTENSION), $valid_formats) )
          {
            $message[] = "$name is not a valid format";
            continue; // Skip invalid file formats
          }
          else 
          { // No error found! Move uploaded files 
              if(move_uploaded_file($_FILES["image_path"]["tmp_name"][$f], $path.$image_path))
              $count++; // Number of successfully uploaded file
          }
      }
         

          $query="insert into event_gallery set event_id='".$event_id."',
                                          image_path='".$image_path."'";
         
         //die($query);
          $run=$GLOBALS['db']->prepare($query);
          $run->execute();
           if($run)
           {
             $msg='Image Uploaded Successfuly';
            header("location:all_event_gallary.php?event_id=$event_id");
           }
            else
            {
             echo $msg='Image Not Uploaded';
             //header("location:event_gallary.php?msg=$msg");
             }

           
  
  
  }
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Event Gallery</title>
    <?php include('includes/bootstrap_header_file.php');?>
     <script>
     function remove_error(field_name){
      $("#"+field_name).html('');
     }
     
      function save_data()
      {
        var image_path=$("#GallaryReg #image_path").val();

        //alert(image_path);
        var counter=1;
        if(image_path==''){counter=0;$("#error_image_path").html('Please Upload Image');}

        if(counter==1){return true;}else{ return false;}

      } 
     </script>

    <head>
    <body>
<form name="GallaryReg" id="GallaryReg" action="event_gallary.php" method="post" onsubmit="return save_data()" enctype="multipart/form-data" class="form-horizontal">
   <div class="form-group">
       <div class="col-lg-2"> <label>Event Name</label></div>
       <div class="col-lg-5"> 
        <input type="hidden" name="event_id" value="<?php echo $event_id;?>" readonly class="form-control"/>
        <?php echo ucwords($fetch_res['event_name']);?></div>
   </div>

<div class="form-group">
       <div class="col-lg-2"><label>Image</label></div>
       <div class="col-lg-10"> 
        <input type="file" id="image_path" name="image_path[]" onclick="remove_error('error_file');" multiple="multiple" accept="image/*">
          <div id="error_image_path" style="color:red;"></div>
      </div>
   </div>
  
<div class="form-group">
	<div class="col-lg-2"></div>
	<div class="col-lg-offset-3 lg-offset-9">
		<button type="submit" name="submit" class="btn btn-default">Submit</button></div>

</div>
</form>
</body>
</html>