<?php 
include("includes/config.php");
 $id=$_GET['id'];

$select="select name,event_name,rating,description ,f.date_added from event_feedback as f inner join member_detail as m on m.id=f.member_id 
inner join event_detail as d on d.id=f.event_id where f.id='$id'";
  $run = $GLOBALS['db']->prepare($select);
  $run->execute();
  $fetch_res=$run->fetch(PDO::FETCH_ASSOC);

  $date_added=date('d-M-Y h:i:s',strtotime($fetch_res['date_added'])); 
?>
<div class="table-responsive">
<table class="table table-bordered table-hover">

<tr>
     <th>Event Name</th>
     <td><?php echo ucwords(strtolower($fetch_res['event_name']));?></td>

     <th>Member Name</th>
     <td><?php echo ucwords(strtolower($fetch_res['name']));?></td>
  </tr>

    <tr>
    <th>Description</th>
    <td colspan="3"><textarea class="form-control" rows="5" readonly ><?php echo $fetch_res['description'];?></textarea></td>
    </tr>
  

    <tr>
      <th>Rating</th>
      <td><?php echo $fetch_res['rating'];?></td>

      <th>Date Added</th>
      <td><?php echo $date_added;?></td>
    </tr>

 </table>
</div>