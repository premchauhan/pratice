<?php 
error_reporting(0);
include("includes/config.php");
include("includes/functions/function_file.php");
 $id=$_GET['event_id'];

  $select="select * from event_detail where id='$id'";
  $run = $GLOBALS['db']->prepare($select);
  $run->execute();
  $fetch_res=$run->fetch(PDO::FETCH_ASSOC); 

?>
<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Event Gallary List</title>
    <?php include('includes/bootstrap_header_file.php');?>
    
</head>
<script>
$(document).ready(function () {
    $(".view_image").elevateZoom({
         //zoomType : "lens", lensShape : "round", lensSize : 250,
         zoomWindowHeight:190,
         zoomWindowWidth:255,
        scrollZoom : true,
        easing : true

      }); 

});

</script>
<body>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
         <!--/////////// top header file /////////-->
            <?php include("includes/top_header.php");?>
             <!-- //////////start left side menu ///////////////////-->
           <?php include('includes/left_side_menu.php');?>
        </nav>
        <div id="page-wrapper">

            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header" style="color:green;">Event Gallery List
                    <a href="event_gallary_list.php" style="margin-left:94%" type="button" class="btn btn-success">Back</a></h3>
                </div>

            <!-- /.row -->
        <div class="row">
       <!-- **********write contant here ************-->
      <div class="col-md-8 col-offset-2">
        <table style="margin-left:4%"class="table table-bordered table-hover">
           <tr>
             <th>Event Name</th>
              <td><?php echo ucwords(strtolower($fetch_res['event_name']));?></td>
              <th>Event Date</th>
              <td><?php echo date('d-M-Y',strtotime($fetch_res['event_date']));?></td>
           </tr>
      
           <tr>
             <th>Event Time</th>
              <td><?php echo $fetch_res['event_time'];?></td>
              <th>Venue</th>
              <td><?php echo ucwords(strtolower($fetch_res['event_venue']));?></td>
           </tr>
        </table>
        

         <div class="col-md-12">
           <div class="col-lg-4"><label>Event Image</label>
            <?php 
                if($fetch_res['event_image']=='')
                {
                 echo '<img src="images/no-image.png" width="150"/><hr>';
                }
                 else
                {
                 echo '<img src="uploads/'.$fetch_res['event_image'].'" width="150"/><hr>';
                 }
            ?>
           </div>
         </div>
    
        <?php 
      	$res =all_event_gallaryList();
        echo '<div class="col-md-12">';
        echo '<div class="col-md-12"><label>Uploaded Image</label></div>';
        echo '<ul class="nav navbar-nav" style="margin-left:3%;">';

        foreach($res as $value)
        {
           $image_path='images/'.$value['image_path'];
            
            if($image_path!='')
            {
              echo  '<li style="margin-bottom:10px;">';
                  echo '<img src="'.$image_path.'" width="60" class="view_image" 
                   data-zoom-image="'.$image_path.'" width="00"/>&nbsp&nbsp&nbsp';
              echo '</li>';
            }
            else{$image_path='';}
      
        }
        echo '</ul>';
         echo '</div>';
        ?>

     </div>
      
     
       
  
  <!-- / end right contant #page-wrapper -->
     <!-- ***************end contant ************-->   
            </div>
            <!-- /.row -->   
        </div>
        <!-- /#page-wrapper -->
    </div>

    <?php include("includes/bottom_footer.php");?>
    </body>
    </html>