<?php 
error_reporting(0);
include("includes/config.php");
$id=$_GET['id'];
if(isset($_REQUEST['submit']))
{
  $title=$_POST['title'];
  $description=$_POST['description'];
  $member_name=$_POST['member_name'];
  $answer=$_POST['answer'];

$update="update event_query set title ='".$title."',
                                description = '".$description."',
                                 member_name ='".$member_name."',
                                 answer ='".$answer."',
                                 date_modify=now()
                                 where id='$id'";

    $run=$GLOBALS['db']->prepare($update);
       $run->execute();
     if($run)
     {
      $msg='Record Updated Successfuly';
      header("location:event_query_list.php?msg=$msg");
    }


}
////for edit code///////
  $select="select * from event_query where id='$id'";
  $run = $GLOBALS['db']->prepare($select);
  $run->execute();
  $fetch_res=$run->fetch(PDO::FETCH_ASSOC);                                    
                               
?>
<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>User Reply</title>
    <?php include('includes/bootstrap_header_file.php');?>

      <script type="text/javascript">
      ///for cancel button ///////
      function cancel_data(){
      window.location.href="event_query_list.php";
      }
      /////////
      function remove_error(field_name){
      $("#"+field_name).html('');

      }
      function save_data()
      {
        
        var answer=$("#answer").val();

        var counter=1;
       if(answer==''){counter=0;$("#error_answer").html('Please Fill Answer');} 
      if(counter==1){return true;}else{ return false;}
      }
      </script>
  </head>
<body>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
         <!--/////////// top header file /////////-->
            <?php include("includes/top_header.php");?>
             <!-- //////////start left side menu ///////////////////-->
           <?php include('includes/left_side_menu.php');?>
        </nav>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12"><h3 class="page-header" style="color:green;">User Reply</h3> </div>
            </div>

            <!-- /.row -->
 <div class="row">
<!-- **********write contant here ************-->
<div class="col-md-6 col-md-offset-2">
 <form action="" method="post" onsubmit="return save_data()" enctype="multipart/form-data" class="form-horizontal">
  
  <div class="col-lg-12">
    <div class="text-center" style="color:green"><?php echo $msg;?></div>
  </div>


  <div class="form-group">
    <div class="col-lg-4"><label>Member Name</label></div>
    <div class="col-lg-8">
      <input type="text" name="member_name" readonly value="<?php echo ucfirst($fetch_res['member_name']);?>" class="form-control">
    </div>
  </div>

  <div class="form-group">
    <div class="col-lg-4"><label>Title</label></div>
    <div class="col-lg-8">
      <input type="text" name="title" readonly value="<?php echo ucfirst($fetch_res['title']);?>"   class="form-control">
    </div>
  </div>

  <div class="form-group">
    <div class="col-lg-4"><label>Description</label></div>
    <div class="col-lg-8">
      <textarea name="description" readonly rows="5"   class="form-control"><?php echo trim($fetch_res['description']);?></textarea>
    </div>
  </div>

<div class="form-group">
    <div class="col-lg-4"><label>Answer <span style="color:red; margin:4px;">*</span></label></div>
    <div class="col-lg-8">
      <textarea name="answer" id="answer" onclick="remove_error('error_answer');" rows="7" class="form-control"><?php echo trim(ucfirst($fetch_res['answer']));?></textarea>
      <div id="error_answer" style="color:red;"></div>
    </div>
  </div>

  <div class="form-group">
    <div class="col-lg-4"></div>
    <div class="col-lg-offset-4 col-lg-8">
      <button type="submit"  name="submit" class="btn btn-success">Submit</button>
      <button type="button"  name="cancel" onclick="cancel_data()" class="btn btn-success">Cancel</button>
    </div>
  </div>
 </form>
  </div>
<!-- ***************end contant ************-->   
    </div>
      <!-- /.row -->   
    </div>
      <!-- /#page-wrapper -->
    </div>

    <?php include("includes/bottom_footer.php");?>
    </body>
    </html>