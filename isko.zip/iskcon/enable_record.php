<?php 
include("includes/config.php");
 error_reporting(0);
$status  = $_REQUEST['status'];
$listArr = $_REQUEST['id'];
$delete_status = $_REQUEST['delete_status'];

$mod=$_REQUEST['mod'];
if($mod=='enable')
{
    $listArr = explode(',',$listArr);
    $listArr = array_unique(array_filter($listArr));

    if(count($listArr)>0  && is_array($listArr))
    {
        $id = "'".implode("','",$listArr)."'";

        $query="update admin_login set status ='".$status."' where id in (".$id.") ";
        $run= $GLOBALS['db']->prepare($query);
        $run->execute();
        if($run)
        {
            echo  'Record Enable Successfuly'; 
        }

    }
    else
    {
        echo 'select Atleast one checkbox';
    } 
} 
//////////////////disable value for///////////
if($mod=='disable') 
{
    $listArr=explode(',',$listArr);
    $listArr=array_unique(array_filter($listArr));
    if(count($listArr)>0 && is_array($listArr))
    {
     $id="'".implode("','",$listArr)."'";
     $query="update admin_login set status ='".$status."' where id in (".$id.") ";
     $run= $GLOBALS['db']->prepare($query);
        $run->execute();
        if($run)
        {
         echo  'Record Disable Successfuly'; 
        }

    }else{echo 'Select Atleast one checkbox';}

} 

//////////delete record for/////

if($mod=='delete')
{
    $listArr=explode(',',$listArr);
    $listArr=array_unique(array_filter($listArr));
     if(count($listArr)>0 && is_array($listArr))
     {
       $id="'".implode("','",$listArr)."'";
       $query="update admin_login set delete_status ='0' where id in (".$id.")";
       //if($delete_status==0){$query="select * from admin_login where delete_status=1";}
        $run= $GLOBALS['db']->prepare($query);
        $run->execute();
        if($run)
            {
             echo 'Record delete successfuly';
            }else{echo 'Select Atleast one checkbox';}

       

     }

}
?>
