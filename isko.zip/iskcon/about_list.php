<?php 
error_reporting(0);
include("includes/config.php");
include("includes/functions/function_file.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>About List</title>
    <?php include('includes/bootstrap_header_file.php');?>
        <script type="text/javascript">

        function description_model(id){
            var options = {
              url:"view_about_description.php?id="+id,
                title:'About Us Description Detail',
                    size: eModal.size.md,
                    buttons: [
                        {text: 'Close', style: 'info',   close: true }

                         ],
                    };

            eModal.ajax(options);

            }

           
        </script>
   </head>
   <body>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
         <!--/////////// top header file /////////-->
            <?php include("includes/top_header.php");?>
             <!-- //////////start left side menu ///////////////////-->
           <?php include('includes/left_side_menu.php');?>
        </nav>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12 text-right" style="color:green"><?php echo $_GET['msg'];?></div>
                <div class="col-lg-12"><h3 class="page-header" style="color:green;">About Us List</h3> </div>
            </div>
            <!-- /.row -->
     <div class="row">
        <!--********* write contant here ******* -->

            <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                              <th>Sr.No</th>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Image</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <?php
                        $counter=1;
                        $res = about_usList();
                        foreach($res as $key=>$value)
                        {
                          $id=$value['id'];
                          $image_path='uploads/'.$value['image'];
                          $edit_path='about_us.php?id='.$id;

                          echo "<tr>";
                            echo '<td>'.$counter++.'</td>';
                            echo '<td>'.$value['title'].'</td>';
                            echo '<td><button onclick="description_model(\''.$id.'\')">View</button></td>';
                             if($value['image']=='')
                             {
                             echo '<td><img src="images/no-image.png" width="75"></td>';
                             }
                              else
                              {
                                echo '<td><img src="'.$image_path.'" width="75"></td>';
                               }
                             echo '<td><a href="'.$edit_path.'"/>Edit</td>';
                          echo "<tr>";

                        }
                       
                        ?>
                                                
                 </table>
            </div>


     <!-- ************end contant ********** -->   
            </div>
            <!-- /.row -->   
        </div>
        <!-- /#page-wrapper -->
    </div>

    <?php include("includes/bottom_footer.php");?>
    </body>
    </html>