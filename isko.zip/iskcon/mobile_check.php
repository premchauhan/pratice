
<?php 
//error_reporting(0); 
include("includes/config.php");
 $mobile_no = $_REQUEST['mobile_no'];
 $id=$_REQUEST['id'];
$query  = "select * from admin_login where mobile_no='".$mobile_no."'and id !='".$id."'";
$run = $GLOBALS['db']->prepare($query);
  $run->execute();
  $fetch_res=$run->fetch(PDO::FETCH_ASSOC); 

if(($fetch_res)>0)
{
	echo 1;
}
else
{
	echo 0;
}

?>