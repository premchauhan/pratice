<?php
error_reporting(0);
include("includes/config.php");
include("includes/functions/function_file.php");

$query ="select * from admin_login where delete_status =1";

if(isset($_POST['submit']))
{
  $search=$_POST['search'];
  $name=$_POST['name'];
  $mobile_no=$_POST['mobile_no'];
  $email=$_POST['email'];
  $status=$_POST['status'];
  $user_name=$_POST['user_name'];

    if($search!='')
    {
    $query.=" and(name like '%".strtoupper($search)."%' or
             mobile_no like '%".strtoupper($search)."%' or
                 email like '%".strtoupper($search)."%' or
                status like '%".strtoupper($search)."%'or
             user_name like '%".strtoupper($search)."%')";

    }

    if($name!=""){ $query.= " and name = '".$name."'"; }
    if($mobile_no!=""){ $query.=" and mobile_no='".$mobile_no."'";}
    if($email!=""){ $query.=" and email='".$email."'";}

    if($status!=''){$query.=" and status='".$status."'";}
}

//echo $query;
$run = $GLOBALS['db']->prepare($query);
$run->execute();

$outputArray = array();
while($res=$run->fetch(PDO::FETCH_ASSOC))
{
  $outputArray[] = $res;
}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Admin User List</title>
    <?php include('includes/bootstrap_header_file.php');?>
    
      <script type="text/javascript">
      $(document).ready(function() {
        $('.tableList').DataTable({
          responsive: true,
          pagingType: "full_numbers",
          lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
          searching : false,

        
        });
      });
      
   

      function view_model(id)
      {
        var options = {
              url:"view_admin_detail.php?id="+id,
              title:'User Detail',
              size: eModal.size.lg,
              buttons: [
                        {text: 'Close', style: 'info',   close: true }
              ],
          };
        eModal.ajax(options);
      } 
      
      ////////////select all checkbox //////
        function select_check_all()
        {
          if(document.getElementById("check_all").checked == true)
          {
            $.each($("input[name='check']"), function(){ 
              var id = $(this).val();
              //alert(id);
              $("#check_"+id).prop('checked', true);
            });
          }
          else
          {
            $.each($("input[name='check']"), function(){            
              var id = $(this).val();
              $("#check_"+id).prop('checked', false);
            });
          }
        }
    

    function enable_data()
    {
      
      var listArr = new Array(); 
      var i=0;
      $.each($("input[name='check']:checked"), function()
      {            
          listArr[i] = $(this).val();
            
         i++;

      });

      if(listArr.length>0)
      {
          $.ajax({
              type:"GET",
              url:'enable_record.php?mod=enable&status=1&id='+listArr,
              async:false,
              success: function(result)
              {
                $("#error_msg").html(result);
              }    
           });

        
      }
      else
      {
        $("#error_msg").html('Select Atleast one checkbox');
      }

      return ;

  }

        //////////////*disable record////////

        function disable_data()
        {
        
          var listArray = new Array(); 
          var id=0;
            $.each($("input[name='check']:checked"), function()
            {
              listArray[id]=$(this).val();
              id++;
            });
          
            if(listArray.length>0)
            {
               $.ajax({
                type:'GET',
                url:'enable_record.php?mod=disable&status=0&id='+listArray,
                async:false,
                  success:function(res)
                  {
                    
                   $("#error_msg").html(res);
                  }
               });

            }
            else
            {
            $("#error_msg").html('Select atlest one checkbox');
            }
            return ;
        }


        /////////////////////delete record////////////

        function delete_data()
        {
          var deleteArray = new Array(); 
          var id=0;
            $.each($("input[name='check']:checked"), function()
            {
             deleteArray[id]=$(this).val();
             id++; 
            });
            
            if(deleteArray.length>0)
            {

              var message = "Are You want to Delete Now";
              eModal.confirm(message, null)
              .then(function(){
                  $.ajax({
                  type:'GET',
                  url:'enable_record.php?mod=delete&delete_status=0&id='+deleteArray,
                   async:false,
                     success:function(delete_res)
                     {
                      $("#error_msg").html(delete_res);
                     } 
                  });
              }); 
            }else{$("#error_msg").html('Select atlest one checkbox');}
          return;
        }
      </script>
 </head>
<body>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
         <!--********* top header file ******-->
            <?php include("includes/top_header.php");?>
             <!-- *******start left side menu ************-->
           <?php include('includes/left_side_menu.php');?>
        </nav>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12 text-right" style="color:green"><?php echo $_GET['msg'];?></div>
                <div class="col-lg-12"><h3 class="page-header" style="color:green;" >Admin User List</h3></div>
            </div>
            <div class="text-right"><h4 id="error_msg" style="color:orange;"></h4></div>
            <!-- /.row -->
     <div class="row">
     <!-- **********write contant here ************-->
      <div class="form-group col-md-12">
          <a href="admin_user.php" class="btn btn-success">Add User</a>
      </div>
    
    <div class="form-group">
          <div class="col-md-4">
            <input type="button" name="enable" value="Enable" onclick="enable_data();"  class="btn btn-success"/>
            <input type="button" name="disable" value="Disable" onclick="disable_data();" class="btn btn-warning"/>
            <input type="button" name="delete" value="Delete" onclick="delete_data();"  class="btn btn-danger"/>
          </div>
        
           <!--search form html -->
          <div class="col-lg-8">
            <form action="" method="post"> 
              <div class="col-lg-5">
                <input type="text" name="search" id="search" placeholder="Search" value="<?php echo $search;?>" class="form-control"/>
              </div>
                
              <div class="col-lg-4">
                <select name="status" id="status" class="form-control">
                 <option value="">Select Status</option>
                 <option value="1">Enable</option>
                 <option value="0">Disable</option>
                </select>
              </div>

              <div class="col-lg-3" style="padding-left:14%" >
                <button type="submit" class="btn btn-success" name="submit"  value="Search">Search</button>
              </div></br></br></br>
          </form>
        </div>
        <!---end ** -->
    </div>

  <div class="table-responsive">
    <table class="table table-bordered table-hover tableList">
       <thead>
        <tr>
          <th>
            <input type="checkbox" id="check_all" name="check_all" value="" 
              onclick="select_check_all();">&nbsp;Sr No.</th>
            <th>Name</th>
            <th>Mobile</th>
            <th>Detail</th>
            <th>Email</th>
            <th>Status</th>
            <th>User Name</th>
            <th>Action</th>
        </tr>
       </thead>
       <tbody>
       <?php
       $counter=1;
       //function
      	//$res = admin_userList();
      	foreach($outputArray as $value)
        {
         $id=$value['id'];
         $edit_path= 'admin_user.php?id='.$id;
          if($value['status']==1){$status= 'Enable';}else{ $status= 'Disable';}
          $delete_status=$value['delete_status'];
        
          echo "<tr>";
            echo '<td>
                <input type="checkbox" name="check" id="check_'.$id.'" 
                    value="'.$id.'">&nbsp;'.$counter++.'</td>';
            echo '<td>'.ucfirst($value['name']).'</td>';
            echo '<td>'.$value['mobile_no'].'</td>';
            echo '<td><a href="#" onclick="view_model(\''.$id.'\')"><i class="fa fa-info-circle">&nbsp info</i></a></td>';
            echo '<td>'.$value['email'].'</td>';
            echo '<td>'.$status.'</td>';
            echo '<td>'.ucwords($value['user_name']).'</td>';
            echo '<td><a href="'.$edit_path.'"/>Edit</a></td>';
          echo "</tr>";
          
        }
        ?>
     </tbody>
    </table>
  </div>
  
  <!-- ***************end contant ************-->   
          </div>
            <!-- /.row -->   
        </div>
        <!-- /#page-wrapper -->
    </div>

    <?php include("includes/bottom_footer.php");?>
    </body>
    </html>