<?php 
error_reporting(0);
include("includes/config.php");
include("includes/functions/function_file.php");

$query="SELECT t1.reminder_date,t1.reminder_time, t1.date_added,t1.date_modify,t2.name,t3.event_name FROM member_event as t1 
inner join member_detail as t2 on t2.id=t1.member_id 
inner join event_detail as t3 on t3.id=t1.event_id where 1=1";
if(isset($_POST['submit']))
{
  $search=$_POST['search'];
  $member_event=$_POST['member_event'];
  $event_name=$_POST['event_name'];
  $start_date=$_POST['start_date'];
  $end_date=$_POST['end_date'];
  
    if($search!='')
    {
    $query.=" and name like '%".strtoupper($search)."%' or
              event_name like '%".strtoupper($search)."%'";
    }

    if($name!=''){$query.= " and t2.name = '".$name."'"; }  
    if($event_name!=''){$query.= " and t3.event_name = '".$event_name."'"; } 

   if($start_date !=""  && $endDate !="")
        {
         $query .= 'and date_format(t1.date_added, "%Y-%m-%d" ) between "'.$start_date.'" AND "'.$end_date.'"';
        }
        else
        {
          if($start_date != ""){$query .= ' and date_format(t1.date_added, "%Y-%m-%d" ) >= date_format("'.$start_date.'","%Y-%m-%d")';}
          if($end_date != "")  {$query .= ' and date_format(t1.date_added, "%Y-%m-%d" ) <= date_format("'.$end_date.'","%Y-%m-%d")';  }
        }
       $query .= " order by t2.name Asc";
}


$run=$GLOBALS['db']->prepare($query);
$run->execute();
  while($fetch_res=$run->fetch(PDO::FETCH_ASSOC))
  {
  $outputArray[]=$fetch_res;  
  }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="description" content="">
      <meta name="author" content="">
      <title>Member Event List</title>
      <?php include('includes/bootstrap_header_file.php');?>

      <script>
       $(document).ready(function () {
            $('#start_date').datepicker({
                format: 'yyyy-mm-dd'
            });

            $('#end_date').datepicker({
                format: 'yyyy-mm-dd'
            });

      });

       ///////paging code///////
       $(document).ready(function() {
        $("#tableList").DataTable({
         responsive: true,
         pagingType: "full_numbers",
         lengthMenu: [[10, 25, 50, -1],[10, 25, 50, "All"]],
         searching: false,
        });
       });
      </script>
  </head>
  <body>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
         <!--/////////// top header file /////////-->
            <?php include("includes/top_header.php");?>
             <!-- //////////start left side menu ///////////////////-->
           <?php include('includes/left_side_menu.php');?>
        </nav>
        <div id="page-wrapper">

            <div class="row">
                <div class="col-lg-12"><h3 class="page-header" style="color:green;">Member Event List</h3> </div>
            </div>

            <!-- /.row -->
    <div class="row">
      <!-- **********write contant here ************-->

      <!--search form html -->
        <div class="form-group col-md-12">
          <form action="" method="post"> 
            <div class=" col-md-offset-2 col-md-3">
              <input type="text" name="search" value="<?php echo $search;?>" id="search" placeholder="Search" class="form-control"></div>
             
             <div class="form-group col-lg-3">
              <input type="text" name="start_date" id="start_date" value="<?php echo $start_date;?>" class="form-control" placeholder="Start Date"/>
             </div>

              <div class="form-group col-md-3">
              <input type="text" name="end_date" id="end_date" value="<?php echo $end_date;?>" class="form-control" placeholder="End Date"/>
              </div>
              <div  class="form-group col-md-1">
                <button type="submit" class="btn btn-success" name="submit" value="Search">Search</button>
              </div>
          </form>
        </div>
        <!-- end  -->

    <div class="table-responsive">
          <table id="tableList" class="table table-bordered table-hover">
             <thead>
              <tr>
                  <th>Sr.No</th>
                  <th>Member Name </th>
                  <th>Event Name</th>
                  <th>Reminder Date</th>
                  <th>Reminder Time</th>
                  <th>Date Added</th>
              </tr>
             </thead>
             <?php
             $counter=1;
             //function
            	//$res = member_eventList();
            	foreach($outputArray as $value)
              {
               $date_added=date('d-M-Y',strtotime($value['date_added']));
               $reminder_date=date('d-M-Y',strtotime($value['reminder_date']));
                echo "<tr>";
                  echo '<td>'.$counter++.'</td>';
                  echo '<td>'.ucwords(strtolower($value['name'])).'</td>';
                  echo  '<td>'. ucwords(strtolower($value['event_name'])).'</td>';
                  echo '<td>'. $reminder_date.'</td>';
                  echo '<td>'. $value['reminder_time'].'</td>';
                  echo '<td>' .$date_added.'</td>';
                echo "</tr>";
             }
            ?>
    </table>
     </div>
     
 <!-- ***************end contant ************-->   
      </div>
           <!-- /.row -->   
     </div>
      <!-- /#page-wrapper -->
    </div>

    <?php include("includes/bottom_footer.php");?>
    </body>
    </html>