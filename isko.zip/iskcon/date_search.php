<?php

$display_Query = "select DISTINCT(SLD.store_id) from `".CO_SELLER_LOGIN_DETAILS."` as SLD
                inner join `".CO_SELLER_LOGIN_ADDRESS."` as SLA on SLD.store_id = SLA.store_id
                where SLD.store_approval = '0' and SLD.del_status = '1'";
 

if(isset($_POST['submit']))
{
        $searchKey = $_POST['searchKey'];
        $countryId                          = $_POST['countryId'];
        $stateId                                = $_POST['stateId'];
        $cityId                    = $_POST['cityId'];
        $businessType  = $_POST['businessType'];
        $startDate = $_POST['startDate'];
        $endDate = $_POST['endDate'];
               
        if($searchKey != "")
        {
                $display_Query .= " and (upper(SLD.store_name)like '%".strtoupper($searchKey)."%' or
                                upper(SLD.owner_name) like '%".strtoupper($searchKey)."%' or
                                upper(SLD.username)   like '%".strtoupper($searchKey)."%' or
                                upper(SLD.reg_mobile) like '%".strtoupper($searchKey)."%' or
                                upper(SLD.reg_email)  like '%".strtoupper($searchKey)."%' ) ";
        }
        if($countryId !="")     { $display_Query .= " and SLA.country_id = '".$countryId."'"; }
        if($stateId !="")       { $display_Query .= " and SLA.state_id = '".$stateId."'"; }
        if($cityId !="")        { $display_Query .= " and SLA.city_id = '".$cityId."'"; }
        if($businessType !="")  { $display_Query .= " and SLD.business_type = '".$businessType."'"; }

        if($startDate !=""  && $endDate !="")
        {
                $display_Query .= ' and date_format(SLD.date_added, "%Y-%m-%d" ) between "'.$startDate.'" AND "'.$endDate.'"';
        }
        else
        {
                if($startDate != ""){$display_Query .= ' and date_format(SLD.date_added, "%Y-%m-%d" ) >= date_format("'.$startDate.'","%Y-%m-%d")';}
                if($endDate != "")  {$display_Query .= ' and date_format(SLD.date_added, "%Y-%m-%d" ) <= date_format("'.$endDate.'","%Y-%m-%d")';  }
        }
}

$display_Query .= " order by SLD.store_name Asc";
$display_result = $obj_CRUD->co_master($display_Query);
 

 



?>