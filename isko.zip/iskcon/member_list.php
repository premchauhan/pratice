<?php 
error_reporting(0);
include("includes/config.php");
include("includes/functions/function_file.php");

$search='';

if(!empty($_POST['sub']))
{
  $search=$_POST['search'];
    
 }

$query="select * from member_detail where name like'%".$search."%' or
        mobile like'%".$search."%' or email like'%".$search."%'order by id desc";

 
$run = $GLOBALS['db']->prepare($query);
       $run->execute();
       while($fetch_res=$run->fetch(PDO::FETCH_ASSOC)){
       $result[]= $fetch_res;
       }
       
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Member List</title>
    <?php include('includes/bootstrap_header_file.php');?>
      <script type="text/javascript">

      function password_model(id){
      var options = {
        url:"view_member_detail.php?id="+id,
          title:'Member Detail',
              size: eModal.size.md,
              buttons: [
                  {text: 'Close', style: 'info',   close: true }

                   ],
              };

      eModal.ajax(options);

      }

      /* Pagination Code start */
      $(document).ready(function() {
        $('.tableList').DataTable({
          responsive: true,
          pagingType: "full_numbers",
          lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
          searching : false,
        });
      });

      </script>
      <style>
 
.btn-page{margin-right:12px;padding:5px 10px; border: green 1px solid;  border-radius:4px;cursor:pointer;}
.btn-page:hover{background:#F0F0F0;}
.btn-page.current{background:blue;}
      </style>
</head>
  <body>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
         <!--/////////// top header file /////////-->
            <?php include("includes/top_header.php");?>
             <!-- //////////start left side menu ///////////////////-->
           <?php include('includes/left_side_menu.php');?>
        </nav>
        <div id="page-wrapper">

            <div class="row">
                <div class="col-lg-12"><h3 class="page-header" style="color:green;">Member List</h3> </div>
            </div>

            <!-- /.row -->
     <div class="row">
      <!-- **********write contant here ************-->
      <!--search form html -->
      <form action="" method="post"> 
       <div class="col-md-offset-7 col-md-3">
       <input type="text" name="search" id="search" value="<?php echo $search;?>" placeholder="Search" class="form-control"></div>

      <div  class="col-md-2" style="padding-left:9%;">
        <button type="submit" class="btn btn-success" name="sub"  value="Search">Search</button>
      </div>
    </form>
 
        <!-- end  -->
    <div class="table-responsive">
      <!--search form html -->
    <table class="table table-bordered table-hover tableList">
       <thead>
        <tr>
            <th>Sr.No</th>
            <th>Name</th>
            <th>Mobile</th>
            <th>Email</th>
            <th>Image</th>
            <th>Action</th>
        </tr>
       </thead>
       <?php
        $counter=1;
      	//$res = memberList();
      	foreach($result as $value)
        {

          $id=$value['id'];
          $image_path='uploads/'.$value['image'];
           
           
          echo "<tr>";
             echo '<td>'.$counter++.'</td>';
             echo '<td>'.ucwords(strtolower($value['name'])).'</td>';
             echo '<td>'.$value['mobile'].'</td>';
             echo '<td>'.$value['email'].'</td>';
             if($value['image']=='')
              {
               echo '<td><img src="images/no-image.png" height="50"></td>';
              }
               else
               {
                echo '<td><img src="'.$image_path.'" width="50"></td>';
               }

             echo '<td><button onclick="password_model(\''.$id.'\')">View</button></td>';
          echo "</tr>";
        }
        ?>
  </table>
  </div>
    

<!-- ***************end contant ************-->   
    </div>
    <!-- /.row -->   
  </div>
    <!-- /#page-wrapper -->
  </div>

  <?php include("includes/bottom_footer.php");?>
  </body>
  </html>