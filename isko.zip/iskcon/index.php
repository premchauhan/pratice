<?php
   error_reporting(0); 
   include("includes/config.php");
   session_start();
   $id=(!empty($_SESSION['sid']))?$_SESSION['sid']:'';
   if(!$id==''){header('location:dashboard.php');}

     if(isset($_REQUEST['login']))
     {

       $mobile_no=$_POST['mobile_no'];
       $password=$_POST['password'];
       
       $select="select * from  admin_login where mobile_no='".$mobile_no."' and password='".$password."'and status=1 ";
       $query=$GLOBALS['db']->prepare($select);

       $query ->execute(array(':mobile_no' =>$mobile_no, ':password' =>$password));
      
       $query->execute();
       
         //Fetch the row.
         $row = $query->fetch(PDO::FETCH_ASSOC);
         //echo $row['id'];
    
       if($query->rowCount() == 1) 
        {
         session_start();
         $_SESSION['sid']       =$row['id']; 
         $_SESSION['user_name'] = $row['user_name']; 
       $_SESSION['email']       =$row['email'];
       $_SESSION['mobile_no']   =$row['mobile_no']; 
       header("location:dashboard.php");
       }else{$msg='User Name and Password Not match';}
     
     }

 ?>
<!DOCTYPE html>
<html lang="en">
 <head>
     <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Login</title>
    <?php include('includes/bootstrap_header_file.php');?>

      <script>
      function remove_error(field_id){
      $("#" +field_id).html('');
      }

      function login_data()
      {
        
      var mobile_no=$("#mobile_no").val();
      var password=$("#password").val();
        var counter=1;
         
        if(mobile_no==''){counter=0; $("#error_mobile").html('Please Fill Mobile No.');}
        if(password==''){counter=0; $("#error_password").html('Please Fill Password');}

           if(counter==1){return true;}else{return false;}

      }
      </script>

      <style>
        .navbar-header{
        background-color: orange;
        padding-right: 88.6%;
   
       }
    </style>
   </head>
   <body>
    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0 ">
   <div class="navbar-header">
        <a class="navbar-brand" href="index.php" style="color:green;">My Dashboard</a>
    </div>
   </nav>

    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Please Sign In</h3>
                    </div>
                    <div class="panel-body">
                        <form action="" method="post" onsubmit="return login_data()">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Mobile" name="mobile_no" id="mobile_no" value="<?php echo $mobile_no;?>" onclick="remove_error('error_mobile');">
                                    <div id="error_mobile" style="color:red"></div>
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" placeholder="Password" name="password" value"<?php echo $password;?>" id="password" onclick="remove_error('error_password');" >
                                   <div id="error_password" style="color:red"></div>
                                </div>
                                <div class="checkbox">
                                    <label>
                                        <input name="remember" type="checkbox" value="Remember Me">Remember Me
                                    </label>
                                </div>
                                <!-- Change this to a button or input when using this as a form -->
                                <input type="submit" name="login" value="Login" class="btn btn-lg btn-success btn-block">
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

   <body>
  </html>