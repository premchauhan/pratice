<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Admin -dashboard</title>
    <?php 
    include('includes/bootstrap_header_file.php');
    include("includes/config.php");
    include("includes/functions/function_file.php");
        // total member///
        $query="select count(*) from member_detail";
        $run = $GLOBALS['db']->prepare($query);
        $run->execute();
        while($res=$run->fetch(PDO::FETCH_ASSOC))
        {
          $total_member= implode(' ',$res);
        }

      ////total event detail////
      $query="select count(*) from event_detail";
        $run = $GLOBALS['db']->prepare($query);
        $run->execute();
        while($res=$run->fetch(PDO::FETCH_ASSOC))
        {
          $total_event_name= implode(' ',$res);
        }
    ?>

</head>
<body>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top"   role="navigation" style="margin-bottom: 0 ">
         <!--/////////// top header file /////////-->
            <?php include("includes/top_header.php");?>
             <!-- //////////start left side menu ///////////////////-->
           <?php include('includes/left_side_menu.php');?>
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header" style="color:green">Dashboard</h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
          <!-- **********write contant here ************-->

                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-comments fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo $total_member;?></div>
                                    <div>Total  Member</div>
                                </div>
                            </div>
                        </div>
                        <a href="member_list.php"> 
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-tasks fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo $total_event_name;?></div>
                                    <div>Total Event </div>
                                </div>
                            </div>
                        </div>
                        <a href="event_detail_list.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
        <!-- ***************end contant ************-->   
            </div>
            <!-- /.row -->   
        </div>
        <!-- /#page-wrapper -->
    </div>

    <?php include("includes/bottom_footer.php");?>
    </body>
    </html>