<?php 
include("includes/config.php");
 $id=$_GET['id'];

$select="select * from admin_login where id='$id'";
  $run = $GLOBALS['db']->prepare($select);
  $run->execute();
  $fetch_res=$run->fetch(PDO::FETCH_ASSOC); 

  $date_added=date('d-M-Y  h:i:s',strtotime($fetch_res['date_added']));
  $last_login=date('d-M-Y',strtotime($fetch_res['last_login']));

  if($fetch_res['status']==1){$status='Enable';}else{$status='Disable';}


?>
   <div class="table-responsive">
    <table class="table table-bordered table-hover">
    <tr>
      <th>Name</th>
      <td><?php echo ucwords(strtolower($fetch_res['name']));?></td>

      <th>Email</th>
      <td><?php echo $fetch_res['email'];?></td>
    </tr>

    <tr>
      <th>Mobile</th>
      <td><?php echo $fetch_res['mobile_no'];?></td>

      <th>Last Login</th>
      <td><?php echo $last_login;?></td>
    </tr>


   <tr>
      <th>Status</th>
      <td><?php echo $status;?></td>

      <th>User Name</th>
      <td><?php echo ucwords(strtolower($fetch_res['user_name']));?></td>
    </tr>

    <tr>
      <th>Gender</th>
      <td><?php echo $fetch_res['gender'];?></td>

      <th>Date Added</th>
      <td><?php echo $date_added;?></td>
    </tr>

    <tr>
      <th>Password</th>
      <td><?php echo $fetch_res['password'];?></td>
    </tr>

 </table>
</div>