<?php 
error_reporting(0);
include("includes/config.php");
include("includes/functions/function_file.php");

$search='';
if(!empty($_POST['submit']))
{
 $search=$_POST['search'];

}
$select="select * from event_query where member_name like '%".$search."%'
 or title like '%".$search."%'order by id desc";
//die($select);
$run=$GLOBALS['db']->prepare($select);
$run->execute();
while($res=$run->fetch(PDO::FETCH_ASSOC))
  {
  $output_array[]=$res; 
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Event Query List</title>
    <?php include('includes/bootstrap_header_file.php');?>
      <script type="text/javascript">
      /////////paging code//////
      $(document).ready(function() {
       $("#tablePaging").DataTable({
        responsive: true,
        pagingType: "full_numbers",
        lengthMenu: [[10, 25, 50, -1],[10, 25, 50, "All"]],
        searching: false,
       });
      });
      /////////////end ///////

      function description_model(id){
      var options = {
        url:"view_event_query_description.php?id="+id,
          title:'Event Query Description Detail',
              size: eModal.size.md,
              buttons: [
                  {text: 'Close', style: 'info',   close: true }

                   ],
              };

      eModal.ajax(options);

      }

      </script>
</head>
  <body>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
         <!--/////////// top header file /////////-->
            <?php include("includes/top_header.php");?>
             <!-- //////////start left side menu ///////////////////-->
           <?php include('includes/left_side_menu.php');?>
        </nav>
        <div id="page-wrapper">

            <div class="row">
                <div class="col-lg-12 text-right" style="color:green"><?php echo $_GET['msg'];?></div>
                <div class="col-lg-12"><h3 class="page-header" style="color:green;">Event Query List</h3> </div>
            </div>

            <!-- /.row -->
     <div class="row">
      <!-- **********write contant here ************-->
     <!--search form html -->
        <div style="margin-bottom:5%">
          <form action="" method="post"> 
            <div class="col-md-offset-8 col-md-3">
              <input type="text" name="search" value="<?php echo $search; ?>" id="search" placeholder="Search" class="form-control"></div>

              <div  class="col-md-1" >
                <button type="submit" class="btn btn-success" name="submit" value="Search">Search</button>
              </div>
          </form>
        </div>
        <!-- end  -->
    <div class="table-responsive">
    <table id="tablePaging" class="table table-bordered table-hover">
       <thead>
        <tr>
            <th>Sr.No</th>
            <th>Member Name</th>
            <th>Title</th>
            <th>Description</th>
            <th>User Reply</th>
            
        </tr>
       </thead>
       <?php
        $counter=1;
      	//$res = event_queryList();
      	foreach($output_array as $key=>$value)
        {
          $id=$value['id'];
          $answer_path='user_reply.php?id='.$id;
          echo "<tr>";
            echo '<td>'.$counter++.'</td>';
            echo '<td>'.ucwords($value['member_name']).'</td>';
            echo '<td>'.ucwords(strtolower($value['title'])).'</td>';
            echo '<td><button onclick="description_model(\''.$id.'\')">View</button></td>';
            echo '<td><a href="'.$answer_path.'">Answer</a></td>';
          echo "</tr>";
        }
        ?>
   


  </table>
   </div>
   
 <!-- ***************end contant ************-->   
            </div>
            <!-- /.row -->   
        </div>
        <!-- /#page-wrapper -->
    </div>

    <?php include("includes/bottom_footer.php");?>
    </body>
    </html>