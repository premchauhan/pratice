<?php 
error_reporting(0);
include("includes/config.php");
include("includes/functions/function_file.php");

 $search='';
//$select="select * from event_detail order by id desc";
if(!empty($_POST['submit']))
{
  $search=$_POST['search'];
}
$select="select * from event_detail where event_name like '%".$search."%'or 
    event_venue like '%".$search."%' or event_date like '%".$search."%' order by id desc";
    
    $run=$GLOBALS['db']->prepare($select);
    $run->execute();
    while($res=$run->fetch(PDO::FETCH_ASSOC))
      {
      $result[]=$res; 
      }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Event Detail List</title>
    <?php include('includes/bootstrap_header_file.php');?>

    <script type="text/javascript">
    $(document).ready(function() {
     $("#pagingTableList").DataTable({
      responsive: true,
      pagingType: "full_numbers",
      lengthMenu: [[10, 25, 50, -1],[10, 25, 50,"All"]],
      searching: false,
     });
    });

      function description_model(id){
      var options = {
        url:"view_event_description.php?id="+id,
          title:'Event Description Detail',
              size: eModal.size.md,
              buttons: [
                  {text: 'Close', style: 'info',   close: true }

                   ],
              };

      eModal.ajax(options);

      }

      </script>
  </head>
  <body>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
         <!--/////////// top header file /////////-->
            <?php include("includes/top_header.php");?>
             <!-- //////////start left side menu ///////////////////-->
           <?php include('includes/left_side_menu.php');?>
        </nav>
        <div id="page-wrapper">

            <div class="row">
                <div class="col-lg-12 text-right" style="color:green"><?php echo $_GET['msg'];?></div>
                <div class="col-lg-12"><h3 class="page-header" style="color:green;">Event List</h3> </div>
            </div>
        <div class="row">
          <!-- **********write contant here ************-->
            <div class="form-group"><a href="event_detail.php"  class="btn btn-success">
            <label>Add Event</label></a></div>

            <!-- **********write contant here ************-->
      <!--search form html -->
      <div>
          <form action="" method="post"> 
            <div class="col-md-offset-8 col-md-3">
              <input type="text" name="search" id="search" value="<?php echo $search;?>" placeholder="Search" class="form-control"></div>

              <div class="col-md-1">
                <button type="submit" class="btn btn-success" name="submit"  value="Search">Search</button>
              </div>
          </form>
       </div>
        <!-- end  -->

            <div class="table-responsive">
            <table id="pagingTableList" class="table table-bordered table-hover">
             <thead>
              <tr>
                  <th>Sr No.</th>
                  <th>Event Name</th>
                  <th>Description</th>
                  <th>Date</th>
                  <th>Time</th>
                  <th>Image</th>
                  <th>Venue</th>
                  <th>Action</th>
                  
              </tr>
             </thead>
            <?php
              $counter=1;
                
               //function
              	//$res = event_detailList();
              	foreach($result as $value)
                { 

                  $id=$value['id'];
                  $image_path= 'uploads/'.$value['event_image'];
                  $edit_path= 'event_detail.php?id='.$id;
                  /////fetch date change format /////
                  $date = $value['event_date'];
                  $date_format= date('d- M - Y', strtotime($date));
                  
                  //$time_format = date('h:i:s a', strtotime($value['event_time']));
                    
                  echo "<tr>";
                    echo '<td>'.$counter++.'</td>';
                    echo '<td>'.ucwords(strtolower($value['event_name'])).'</td>';
                    echo '<td><button onclick="description_model(\''.$id.'\')">View</button></td>';
                    echo '<td>'.$date_format.'</td>';
                    echo '<td>'.$value['event_time'].'</td>';

                    if($value['event_image']=='')
                    {
                     echo '<td><img src="images/no-image.png" height="70"></td>';

                     }else{echo '<td><img src="'.$image_path.'" width="75"></td>';}
                    
                    echo '<td>'.ucwords(strtolower(substr($value['event_venue'],0,25))).'</td>';
                    echo  '<td>
                              <a href="'.$edit_path.'">Edit</a></td>';
          
                echo "</tr>";
              }
            ?>

            </table>
         </div>
        
     <!-- ***************end contant ************-->   
            </div>
            <!-- /.row -->   
        </div>
        <!-- /#page-wrapper -->
    </div>

    <?php include("includes/bottom_footer.php");?>
    </body>
    </html>