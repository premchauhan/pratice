<?php 
error_reporting(0);
include("includes/config.php");
$id=$_GET['id'];
if(isset($_REQUEST['submit']))
{
$event_name=$_POST['event_name'];
$event_description=$_POST['event_description'];
$event_date=$_POST['event_date'];
$event_time = date('h:i a', strtotime($_POST['event_time']));

  if(!empty($_FILES['event_image']['name']))
  {
    $event_image=$_FILES['event_image']['name'];
    $temp_name=$_FILES['event_image']['tmp_name'];
    move_uploaded_file($temp_name, 'uploads/'.$event_image);
  }else{$event_image=$_POST['old_image'];}

  $event_venue=$_POST['event_venue'];

if($id>0)
{
$update="update event_detail set event_name ='".$event_name."',
                                      event_description = '".$event_description."',
                                      event_date = '".$event_date."',
                                      event_time = '".$event_time."',
                                         event_image ='".$event_image."',
                                         event_venue = '".$event_venue."',
                                         date_modify=now()
                                         where id='$id'";

    $run=$GLOBALS['db']->prepare($update);
       $run->execute();
     if($run)
     {
      $msg='Record Updated Successfuly';
      header("location:event_detail_list.php?msg=$msg");
    }
}
else
{

  $query="insert into event_detail set event_name ='".$event_name."',
                                      event_description = '".$event_description."',
                                      event_date = '".$event_date."',
                                      event_time = '".$event_time."',
                                         event_image ='".$event_image."',
                                         event_venue = '".$event_venue."'";

    $run=$GLOBALS['db']->prepare($query);
       $run->execute();
     if($run)
     {
      $msg='Record Inserted Successfuly';
      header("location:event_detail_list.php?msg=$msg");
    }else{$msg='Record Not Inserted';} 
  }
}
////for edit code///////
if(isset($id) && $id!='')
{
  $select="select * from event_detail where id='$id'";
  $run = $GLOBALS['db']->prepare($select);
  $run->execute();
  $fetch_res=$run->fetch(PDO::FETCH_ASSOC);

       $event_name   =ucwords($fetch_res['event_name']);
  $event_description =trim($fetch_res['event_description']);
       $event_date   =$fetch_res['event_date'];
       $event_time   =$fetch_res['event_time'];
       $event_venue  =trim($fetch_res['event_venue']);
       $event_image  ='uploads/'.$fetch_res['event_image'];
        

}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Event Detail</title>
    <?php include('includes/bootstrap_header_file.php');?>
        <script type="text/javascript">
        $(document).ready(function () {
            $('#event_date').datepicker({
                format: 'yyyy-mm-dd'
            });
   
            $('#event_time').timepicker({
                minuteStep :1,                 
                maxHours: 24,
                showMeridian :false              
            });
        });
        
      function remove_error(field_name){
      $("#"+field_name).html('');

      }


        function save_data()
        {
          
          var event_name=$("#event_name").val();
          var event_description=$("#event_description").val();
          var event_date=$("#event_date").val();
          var event_time=$("#event_time").val();
          var event_venue=$("#event_venue").val();
          

          var counter=1;
         if(event_name==''){counter=0;$("#error_event_name").html('Please Fill Event Name');}
         if(event_description==''){counter=0;$("#error_event_description").html('Please Fill Event description');}
         if(event_date==''){counter=0;$("#error_event_date").html('Please Select Event Date');}
         if(event_time==''){counter=0;$("#error_event_time").html('Please Select Event Time');}
         if(event_venue==''){counter=0;$("#error_event_venue").html('Please Fill Event Venue');}
         
        if(counter==1){return true;}else{ return false;}
        }

        </script>
        
    </head>
   <body>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
         <!--/////////// top header file /////////-->
            <?php include("includes/top_header.php");?>
             <!-- //////////start left side menu ///////////////////-->
           <?php include('includes/left_side_menu.php');?>
        </nav>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                <h3 class="page-header" style="color:green;">Event Detail</h3>
                 </div>
            </div>
     <div class="row">
        <!--********* write contant here ********* -->

       <div class="col-md-6 col-md-offset-2">
       <form action="" method="post" onsubmit="return save_data()" enctype="multipart/form-data" class="form-horizontal">
        <div class="col-lg-12">
          <div class="text-center" style="color:green"><?php echo $msg;?></div>
        </div>
      
        <div class="form-group">
          <div class="col-lg-4"><label>Name</label></div>
          <div class="col-lg-8">
            <input type="text" name="event_name" value="<?php echo $event_name;?>" id="event_name"  onclick="remove_error('error_event_name');" class="form-control">
            <div id="error_event_name" style="color:red;"></div>
          </div>
        </div>

        <div class="form-group">
          <div class="col-lg-4"><label>Description</label></div>
          <div class="col-lg-8">
            <textarea name="event_description"  rows="5" id="event_description" onclick="remove_error('error_event_description');" class="form-control"><?php echo $event_description;?></textarea>
            <div id="error_event_description" style="color:red;"></div>
          </div>
        </div>

        <div class="form-group">
          <div class="col-lg-4"><label>Date</label></div>
          <div class="col-lg-8">
            <input type="text" name="event_date"  value="<?php echo $fetch_res['event_date'];?>" id="event_date"  onclick="remove_error('error_event_date');" class="form-control">
            <div id="error_event_date" style="color:red;"></div>
          </div>
        </div>


        <div class="form-group">
          <div class="col-lg-4"><label>Start Time</label></div>
          <div class="col-lg-8">
            <input type="text" name="event_time" value="<?php echo $event_time;?>" id="event_time"  onclick="remove_error('error_event_time');" class="form-control">
            <div id="error_event_time" style="color:red;"></div>
          </div>
        </div>


       <div class="form-group">
          <div class="col-lg-4"><label>Venue</label></div>
          <div class="col-lg-8">
            <textarea name="event_venue"  rows="3" id="event_venue" onclick="remove_error('error_event_venue');" class="form-control"><?php echo $event_venue;?></textarea>
            <div id="error_event_venue" style="color:red;"></div>
          </div>
        </div>

        <div class="form-group">
          <div class="col-lg-4"><label>Image</label></div>
          <div class="col-lg-8">
            <?php
             $old_image   =$fetch_res['event_image'];
             if(file_exists($event_image)&& $old_image !='' )
             {
               echo '<img src="'.$event_image.'" width="75">';
               
                 echo '<input type="hidden" name="old_image" value="'.$old_image.'"/>';
              }
              echo '<br></br>';
              echo '<input type="file" name="event_image">';
              ?>
          </div>
        </div>

       
        <div class="form-group">
          <div class="col-lg-4"></div>
          <div class="col-lg-offset-4 col-lg-8">
            <button type="submit" name="submit"  class="btn btn-success">Submit</button>
            <a href="event_detail_list.php" type="button"   class="btn btn-success">Cancel</a>
          </div>
        </div>
       </form>
      </div>
    <!-- *********end contant *************-->   
            </div>
            <!-- /.row -->   
        </div>
        <!-- /#page-wrapper -->
    </div>

    <?php include("includes/bottom_footer.php");?>
    </body>
    </html>