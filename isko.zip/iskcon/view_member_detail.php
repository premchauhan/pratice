<?php 
include("includes/config.php");
 $id=$_GET['id'];

$select="select * from member_detail where id='$id'";
  $run = $GLOBALS['db']->prepare($select);
  $run->execute();
  $fetch_res=$run->fetch(PDO::FETCH_ASSOC); 

  $date_added=date('d-M-Y h:i:s',strtotime($fetch_res['date_added']));
?>
<div class="table-responsive">
<table class="table table-bordered table-hover">
  <tr>
     <th>Name</th>
     <td><?php echo ucwords(strtolower($fetch_res['name']));?></td>

     <th>Email</th>
     <td><?php echo $fetch_res['email'];?></td>
  </tr>

   <tr>
     <th>Mobile</th>
     <td><?php echo $fetch_res['mobile'];?></td>

     <th>Image</th>
     <?php 
     if($fetch_res['image']=='')
       {
        echo '<td><img src="images/no-image.png" width="75"></td>';
       }
         else
         {
          echo '<td><img src="uploads/'.$fetch_res['image'].'" width="75"></td>';
         }
     ?>
  </tr>

   <tr>
     <th>Otp</th>
     <td><?php echo $fetch_res['otp'];?></td>

     <th>Date Added</th>
     <td><?php echo $date_added;?></td>
   </tr>
 </table>
</div>
  