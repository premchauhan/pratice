<?php 
error_reporting(0);
include("includes/config.php");
include("includes/functions/function_file.php");

$select="select * from daily_quotes where 1=1";

if(isset($_POST['sub']))
{
  
 $search=$_POST['search'];


    if($search!='')
    {
      $select.=" and (quotes_name like '%".strtoupper($search)."%' or 
                            title like '%".strtoupper($search)."%')";
    }
                     
}

 $select.= " order by id desc";
$run=$GLOBALS['db']->prepare($select);
$run->execute();
while($res=$run->fetch(PDO::FETCH_ASSOC))
  {
  $output_array[]=$res; 
  }


?>
<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Event News List</title>
    <?php include('includes/bootstrap_header_file.php');?>
        <script type="text/javascript">
          $(document).ready(function() {
            $('.pagingTableList').DataTable({
             responsive: true,
             pagingType: "full_numbers",
             lengthMenu: [[10, 25, 50, -1],[10,25, 50, "All"]],
             searching: false,
            });
          });
       

        function description_model(id){
        var options = {
          url:"view_daily_quotes_description.php?id="+id,
            title:'Daily Quotes Description Detail',
                size: eModal.size.md,
                buttons: [
                    {text: 'Close', style: 'info',   close: true }

                     ],
                };

        eModal.ajax(options);

        }

      
        </script>
  </head>
 <body>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
         <!--/////////// top header file /////////-->
            <?php include("includes/top_header.php");?>
             <!-- //////////start left side menu ///////////////////-->
           <?php include('includes/left_side_menu.php');?>
        </nav>
        <div id="page-wrapper">

            <div class="row">
                <div class="col-lg-12 text-right" style="color:green"><?php echo $_GET['msg'];?></div>
                <div class="col-lg-12"><h3 class="page-header" style="color:green;">Daily Quotes List</h3> </div>
            </div>

            <!-- /.row -->
   <div class="row">
   <!-- **********write contant here ************-->
        
    <div class="form-group">
      <a href="daily_quotes.php" type="button" class="btn btn-success">
      <label>Add Quotes</label></a>
  </div>

  <div class="form-group">
    <form action="" method="post"> 
     <div class="col-md-offset-8 col-md-3">
      <input type="text" name="search" id="search" placeholder="Search" value="<?php echo $search;?>" class="form-control"/>
     </div>

     <div class="col-md-1">
        <button type="submit" class="btn btn-success" name="sub"  value="Search">Search</button>
     </div>
  </form>
  </div>

    <div class="table-responsive">
    <table class="table table-bordered table-hover pagingTableList">
       <thead>
        <tr>
            <th>Sr.No</th>
            <th>Quotes Name</th>
            <th>Title</th>
            <th>Image</th>
            <th>Description</th>
            <th>Action</th>
            
        </tr>
       </thead>
       <?php
        $counter=1;
        //function
      	//$res = daily_quotesList();
      	foreach($output_array as $key=>$value)
        {
          $image_path='uploads/'.$value['image'];
          $id=$value['id'];
          $edit_path='daily_quotes.php?id='.$id;

          echo "<tr>";
            echo '<td>'.$counter++.'</td>';
            echo '<td>'.ucwords($value['quotes_name']).'</td>';
            echo '<td>'.ucwords(strtolower($value['title'])).'</td>';
            echo '<td><img src="'.$image_path.'" width="75"></td>';
            echo '<td><button onclick="description_model(\''.$id.'\')">View</button></td>';
            echo '<td><a href="'.$edit_path.'">Edit</a></td>';
          echo "</tr>";
        }
        ?>
    

    </table>
    </div>

  <!-- ***************end contant ************-->   
    </div>
      <!-- /.row -->   
    </div>
      <!-- /#page-wrapper -->
    </div>

    <?php include("includes/bottom_footer.php");?>
    </body>
    </html>