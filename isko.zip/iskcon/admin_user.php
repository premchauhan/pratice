<?php 
error_reporting(0);
include("includes/config.php");
//$id=$_GET['id'];
$id= ($_GET['id'])?$_GET['id']:0;

if(isset($_REQUEST['submit']))
{
    $name       = ucwords($_POST['name']);
    $last_name  = ucwords($_POST['last_name']);
    $mobile_no  = $_POST['mobile_no'];
    $email      = $_POST['email'];
    $gender     = $_POST['gender'];
    

    if($id>0)
    {
         $query= "update admin_login set name ='".$name."', last_name ='".$last_name."', 
                    email ='".$email."', mobile_no = '".$mobile_no."', gender = '".$gender."'
                    where id='".$id."'";
        $run=$GLOBALS['db']->prepare($query);
        $run->execute();
        if($run)
        {
          $msg='Record Updated Successfuly';
          header("location:admin_user_list.php?msg=$msg");
          exit();
        } 
    }
    else
    {
        $password = uniqid();
        $password=substr($password,0,6);

          $query="insert into admin_login set name ='".$name."', last_name ='".$last_name."',
                    email ='".$email."', mobile_no = '".$mobile_no."', gender = '".$gender."', 
                    password ='".md5($password)."', confirm_password='".$password."',
                    user_name ='".$user_name."'";

        $run=$GLOBALS['db']->prepare($query);
        $run->execute();
        if($run)
        {
           $last_id=$GLOBALS['db']->lastInsertId();  ///for last id fetch db function////
            $user_name=substr($name,0,2).$last_name.$last_id;
           
              $update_query="update admin_login set user_name='".$user_name."' where id='".$last_id."'";
              $run=$GLOBALS['db']->prepare($update_query);
              $run->execute();
                  
            $msg='Record Inserted Successfuly';
            header("location:admin_user_list.php?msg=$msg");
            
            exit();
        }
        else
        {
          $msg='Record Not Inserted';
        } 
    }
}

 if(isset($_GET['id']) && $_GET['id'] != '')
{
  $select="select * from admin_login where id='$id'";
  $run = $GLOBALS['db']->prepare($select);
  $run->execute();
  $fetch_res =$run->fetch(PDO::FETCH_ASSOC);                                    

  $id        =$_GET['id'];
  $name      =ucwords($fetch_res['name']);
  $last_name =ucwords($fetch_res['last_name']);
  $email     =$fetch_res['email'];
  $mobile_no =$fetch_res['mobile_no'];
  $gender    =$fetch_res['gender'];
}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Admin User</title>
    <?php include('includes/bootstrap_header_file.php');?>
        <script type="text/javascript">

      function mobile_duplicate(mobile_no)
      {
     
       var output = 0;
        //alert('mobile_check.php?mobile_no='+mobile_no+'&id='+<?php echo $id; ?>);
       $.ajax({
           type: "GET",
           url:'mobile_check.php?mobile_no='+mobile_no+'&id='+<?php echo $id; ?>,
           async: false,
           success:function(result)
              {
                //alert(result);
                if(result == 1){ output =1; }
              }
          }); 

       return output;
      }

    
        function remove_error(field_name){
        $("#"+field_name).html('');

        }

      
    function save_data()
    {
     
      var name=$("#name").val();
      var last_name=$("#last_name").val();
      var mobile_no=$("#mobile_no").val();
      
          var counter=1;
         if(name==''){counter=0;$("#error_name").html('Please Fill name');}
         if(last_name==''){counter=0;$("#error_last_name").html('Please Fill Last Name');}
         if(mobile_no==''){counter=0;$("#error_mobile_no").html('Please Fill Mobile No.');}
         else
        {
          if(isNaN(mobile_no)){counter=0; $("#error_mobile_no").html('Please Enter Digit Only');}
          else if(mobile_no.length!=10){counter=0; $("#error_mobile_no").html('Please enter only 10 degit no.');}
           else
           {

            //alert(mobile_no);
             var mobExist = mobile_duplicate(mobile_no);
               if(mobExist == '1')
               {
                  counter=0;
                  $("#error_mobile_no").html("This mobile no Already Exits");       
                }
            }

          }

             var email = document.getElementById('email');
              var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
              
                  if (!filter.test(email.value)) 
                  {
                  counter=0;
                  $("#error_email").html('Please provide a valid email address');
                  }
        
          if(counter==1){return true;}else{ return false;}
        }
        </script>
  </head>
 <body>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
         <!--/////////// top header file /////////-->
            <?php include("includes/top_header.php");?>
             <!-- //////////start left side menu ///////////////////-->
           <?php include('includes/left_side_menu.php');?>
        </nav>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12"><h3 class="page-header" style="color:green;">Admin User</h3> </div>
            </div>
         <!-- /.row -->
        <div class="row">
          <!-- **********write contant here ************--> 
 <div class="col-md-6 col-md-offset-2">
 <form action="" method="post" onsubmit="return save_data()" enctype="multipart/form-data" class="form-horizontal">
  
  <div class="col-lg-12">
    <div class="text-center" style="color:green"><?php echo $msg;?></div>
  </div>

  <div class="form-group">
 		<div class="col-lg-4"><label>First Name</label></div>
 		<div class="col-lg-8">
 			<input type="text" name="name" id="name" value="<?php echo $name;?>" onclick="remove_error('error_name');" class="form-control">
      <div id="error_name" style="color:red;"></div>
 		</div>
 	</div>

  <div class="form-group">
    <div class="col-lg-4"><label>Last Name</label></div>
    <div class="col-lg-8">
      <input type="text" name="last_name" id="last_name" value="<?php echo $last_name;?>" onclick="remove_error('error_last_name');" class="form-control">
      <div id="error_last_name" style="color:red;"></div>
    </div>
  </div>

    <div class="form-group">
 		<div class="col-lg-4"><label>Email</label></div>
 		<div class="col-lg-8">
 			<input type="text" name="email" value="<?php echo $email;?>" id="email" onclick="remove_error('error_email');" class="form-control">
      <div id="error_email" style="color:red;"></div>
 		</div>
 	</div>
  <div class="form-group">
    <div class="col-lg-4"><label>Mobile No.</label></div>
    <div class="col-lg-8">
      <input type="text" name="mobile_no" onchange="mobile_duplicate(this.value)" value="<?php echo $mobile_no;?>" id="mobile_no" onclick="remove_error('error_mobile');" class="form-control">
      <div id="error_mobile_no" style="color:red;"></div>
    </div>
  </div>

  <div class="form-group">
    <div class="col-lg-4"><label>Gender</label></div>
    <div class="col-lg-8">
      <?php $genderArr=array('Male','Female');
      foreach($genderArr as $val)
      {
        
        if(!isset($gender) && $gender=='' && $val=='Male'){
          $selected="checked='checked'";
        }
        else if ($gender == $val) { $selected = "checked='checked'"; }
        else{ $selected = '';}

       echo '<li style="display: inline;"><lable>
       <input type="radio" name="gender" value="'.$val.'" '.$selected.' id="gender">'.$val.'</label></li>';
       }
      ?>
      
    </div>
  </div>

  <div class="form-group">
    <div class="col-lg-4"></div>
    <div class="col-lg-offset-4 col-lg-8">
      <button type="submit" name="submit"  class="btn btn-success">Submit</button>
      <a href="admin_user_list.php" type="button"   class="btn btn-success">Cancel</a>
    </div>
  </div>
 </form>
</div>
   <!-- ***************end contant ************-->   
        </div>
        <!-- /.row -->   
    </div>
    <!-- /#page-wrapper -->
   </div>

  <?php include("includes/bottom_footer.php");?>
  </body>
  </html>