<?php 
error_reporting(0);
include("includes/config.php");

$id= 1;
if(isset($_REQUEST['submit']))
{
  
  $title=ucwords($_POST['title']);
  $description=$_POST['description'];
  if(!empty($_FILES['image']['name']))
  {
    $image_name=$_FILES['image']['name'];
    $temp_name=$_FILES['image']['tmp_name'];
    move_uploaded_file($temp_name, 'uploads/'.$image_name);
  }
  else{$image_name=$_POST['old_image'];}

  if($id>0)
  {
    $update="update about_us set title ='".$title."',
                                      description = '".$description."',
                                         image ='".$image_name."',
                                         date_modify=now()
                                         where id='$id'";

    $run=$GLOBALS['db']->prepare($update);
       $run->execute();
     if($run)
     {
      $msg='Record Updated Successfuly';
      header("location:about_list.php?msg=$msg");
    }
}
else
{

  $query="insert into about_us set title ='".$title."',
                                      description = '".$description."',
                                         image ='".$image_name."'";

    $run=$GLOBALS['db']->prepare($query);
       $run->execute();
     if($run)
     {
      $msg='Record Inserted Successfuly';
      header("location:about_list.php?msg=$msg");
    }else{$msg='Record Not Inserted';} 
  }
}
////for edit code///////
  $select="select * from about_us where id='$id'";
  $run = $GLOBALS['db']->prepare($select);
  $run->execute();
  $fetch_res=$run->fetch(PDO::FETCH_ASSOC);                                    
                                  
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>About Us</title>
    <?php include('includes/bootstrap_header_file.php');?>
  
      <script type="text/javascript">
        function remove_error(field_name){
        $("#"+field_name).html('');

        }
        function save_data()
        {
          
          var title=$("#title").val();
          var description=$("#description").val();
          

          var counter=1;
         if(title==''){counter=0;$("#error_title").html('Please Fill Title');}
         if(description==''){counter=0;$("#error_description").html('Please Fill description');}
         
        if(counter==1){return true;}else{ return false;}
        }
      </script>
 </head>
<body>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
         <!--/////////// top header file /////////-->
            <?php include("includes/top_header.php");?>
             <!-- //////////start left side menu ///////////////////-->
           <?php include('includes/left_side_menu.php');?>
        </nav>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12"><h3 class="page-header" style="color:green;">About Us</h3> </div>
            </div>

            <!-- /.row -->
        <div class="row">
          <!-- **********write contant here ************-->
          <div class="col-md-6 col-md-offset-2">   
         <form action="" method="post" onsubmit="return save_data()" enctype="multipart/form-data" class="form-horizontal">
          
            <div class="col-lg-12">
              <div class="text-center" style="color:green"><?php echo $msg;?></div>
            </div>


              <div class="form-group">
                <div class="col-lg-4"><label>Title</label></div>
                <div class="col-lg-8">
                  <input type="text" name="title" value="<?php echo $fetch_res['title'];?>" id="title"  onclick="remove_error('error_title');" class="form-control">
                  <div id="error_title" style="color:red;"></div>
                </div>
              </div>

              <div class="form-group">
                <div class="col-lg-4"><label>Description</label></div>
                <div class="col-lg-8">
                  <textarea name="description"  rows="8" id="description" onclick="remove_error('error_description');" class="form-control"><?php echo trim($fetch_res['description']);?></textarea>
                  <div id="error_description" style="color:red;"></div>
                </div>
              </div>

              <div class="form-group">
                <div class="col-lg-4"><label>Image</label></div>
                <div class="col-lg-8">
                  <?php
                  if($fetch_res['image']!='' && $fetch_res['image']!='')
                  { 
                   echo '<img src="uploads/'.$fetch_res['image'].'" width="75">';

                   echo '<input type="hidden" name="old_image" value="'.$fetch_res['image'].'">';
                   echo '<br><br>';
                  }

                   echo '<input type="file" name="image">';
                 ?>
                </div>
              </div>

              <div class="form-group">
                <div class="col-lg-4"></div>
                <div class="col-lg-offset-4 col-lg-8">
                  <button type="submit" name="submit" class="btn btn-success">Submit</button>
                  <!--<a href="about_list.php" type="button"  name="cancel" class="btn btn-success">Cancel</a>-->
                </div>
              </div>
           </form>
         </div>
      <!-- ***************end contant ************-->   
            </div>
            <!-- /.row -->   
        </div>
        <!-- /#page-wrapper -->
    </div>

    <?php include("includes/bottom_footer.php");?>
    </body>
    </html>