<div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a>
                        </li>
                        
                        <li>
                          <?php include("includes/config.php"); ?>
          
                          <a href="about_us.php"><i class="fa fa-table fa-fw"></i>About Us</a>
                           
                        </li>
                          
                         <li>
                            <a href="admin_user_list.php"><i class="fa fa-edit fa-fw"></i>Admin User</a>
                        </li>

                        <li>
                            <a href="#"><i class="fa fa-table fa-fw"></i>Member<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                          <li>
                            <a href="member_list.php"><i class="fa fa-edit fa-fw"></i>Member Detail</a>
                           </li>
                               <li>
                              <a href="member_event_list.php"><i class="fa fa-edit fa-fw"></i>Member Event</a>
                            </li> 
                            </ul>
                            <!--/.nav-second-level -->
                       </li>

                       <li>
                            <a href="#"><i class="fa fa-wrench fa-fw"></i>Event<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                   <a href="event_detail_list.php"><i class="fa fa-edit fa-fw"></i>Event Detail</a>
                               </li>
                               <li>
                                   <a href="event_gallary_list.php"><i class="fa fa-edit fa-fw"></i>Event Gallary</a>
                               </li>

                                <li>
                                  <a href="event_query_list.php"><i class="fa fa-table fa-fw"></i>Event Query</a>
                                </li>

                                <li>
                                 <a href="daily_quotes_list.php"><i class="fa fa-table fa-fw"></i>Daily Quotes</a>
                               </li>

                                <li>
                                   <a href="event_feedback_list.php"><i class="fa fa-edit fa-fw"></i>Event Feedback</a>
                               </li>
                            </ul>
                            <!--/.nav-second-level -->
                       </li>  
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
</div>