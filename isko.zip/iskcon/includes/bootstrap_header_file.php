<!-- Bootstrap Core CSS -->
    <link href="library/css/bootstrap.min.css" rel="stylesheet">

    
    <!-- Custom Fonts -->
    <link href="library/css/font-awesome.min.css" rel="stylesheet" type="text/css">
   
    <!-- Bootstrap Core JavaScript -->
    <script src="library/js/jquery-1.9.1.min.js"></script>
    <!--<script src="library/js/jquery.min.js"></script>-->
    <script src="library/js/bootstrap.min.js"></script>
     
    <!-- Metis Menu Plugin JavaScript -->
    <script src="library/js/eModal.min.js"></script>
    <script src="library/js/metisMenu.min.js"></script>

    <!--datepicker file-->
    <link href="library/css/bootstrap-datepicker.css" rel="stylesheet">
    <script src="library/js/bootstrap-datepicker.js"></script>

     <!--timepicker file --> 
     <link rel="stylesheet" type="text/css" href="library/css/jquery.timepicker.css" />
     <script src="library/js/jquery.timepicker.js"></script>

    <!--dataTable file- -->
    <link href="library/css/dataTables.bootstrap.css" rel="stylesheet">
    <link href="library/css/dataTables.responsive.css" rel="stylesheet">
    <script src="library/js/jquery.dataTables.min.js"></script>
    <script src="library/js/dataTables.bootstrap.min.js"></script>
    <script src="library/js/dataTables.responsive.js"></script>

     <!--image zoom- -->
     <script type="text/javascript" src="library/js/jquery.elevatezoom.min.js"></script>

    <!-- Custom CSS  and js file-->
    <link href="library/css/sb-admin-2.css" rel="stylesheet">
    <script src="library/js/sb-admin-2.js"></script>

     
