<?php 
function memberList()
{
	$outputArray=array();
	 
	$query="select * from member_detail order by id desc ";
	//die($query);
	$run = $GLOBALS['db']->prepare($query);
	$run->execute();
	while($res=$run->fetch(PDO::FETCH_ASSOC))
	{
     	$outputArray[] = $res;
	}
	return $outputArray;
     
}
//////for admin user///////
function admin_userList()
{
	$outputArray=array();
	$query="select * from admin_login order by id desc ";
	$run = $GLOBALS['db']->prepare($query);
	$run->execute();
	while($res=$run->fetch(PDO::FETCH_ASSOC))
	{
     	$outputArray[] = $res;
	}
	return $outputArray;
}



function about_usList()
{
	$outputArray=array();
	$query="select * from about_us order by id desc ";
	$run = $GLOBALS['db']->prepare($query);
	$run->execute();
	while($res=$run->fetch(PDO::FETCH_ASSOC))
	{
     	$outputArray[] = $res;
	}
	return $outputArray;
}


function event_detailList()
{

$output_array=array();
$select="select * from event_detail order by id desc";
$run=$GLOBALS['db']->prepare($select);
$run->execute();
while($res=$run->fetch(PDO::FETCH_ASSOC))
	{
	$output_array[]=$res;	
	}
	return $output_array;	
}

////////////
function daily_quotesList()
{

$output_array=array();
$select="select * from daily_quotes order by id desc";
$run=$GLOBALS['db']->prepare($select);
$run->execute();
while($res=$run->fetch(PDO::FETCH_ASSOC))
	{
	$output_array[]=$res;	
	}
	return $output_array;	
}

//////////////
function event_queryList()
{

$output_array=array();
$select="select * from event_query order by id desc";
$run=$GLOBALS['db']->prepare($select);
$run->execute();
while($res=$run->fetch(PDO::FETCH_ASSOC))
	{
	$output_array[]=$res;	
	}
	return $output_array;	
}

//////////
function event_feedbackList()
{

$output_array=array();
$select="select f.id,name,event_name,rating from event_feedback as f inner join member_detail as m on m.id=f.member_id 
inner join event_detail as d on d.id=f.event_id";
$run=$GLOBALS['db']->prepare($select);
$run->execute();
while($res=$run->fetch(PDO::FETCH_ASSOC))
	{
	$output_array[]=$res;	
	}
	return $output_array;	
}

////////////////

function member_eventList()
{
$outputArray=array();
$query="SELECT t1.date_added,t1.date_modify,name,event_name,reminder_date,reminder_time FROM member_event as t1 inner join member_detail as t2 on t2.id=t1.member_id 
inner join event_detail as t3 on t3.id=t1.event_id";
$run=$GLOBALS['db']->prepare($query);
$run->execute();
	while($fetch_res=$run->fetch(PDO::FETCH_ASSOC))
	{
	$outputArray[]=$fetch_res;	
	}
   return $outputArray;
}


function all_event_gallaryList()
{

$outputArray=array();
$event_id=$_GET['event_id'];
//$query="select * from event_gallery order by id desc";
$query="SELECT image_path FROM `event_gallery`inner join event_detail 
on event_detail.id=event_gallery.event_id  where event_gallery.event_id='$event_id'";
//die($query);
$run=$GLOBALS['db']->prepare($query);
$run->execute();
	while($fetch_res=$run->fetch(PDO::FETCH_ASSOC))
	{
	$outputArray[]=$fetch_res;	
	}
   return $outputArray;
}

/////////////////
function event_gallaryList()
{

$outputArray=array();
$query="SELECT distinct t2.*,t1.event_id FROM `event_gallery` as t1 inner join event_detail as t2 on t1.event_id=t2.id";
//die($query);
$run=$GLOBALS['db']->prepare($query);
$run->execute();
	while($fetch_res=$run->fetch(PDO::FETCH_ASSOC))
	{
	$outputArray[]=$fetch_res;	
	}
   return $outputArray;
}

?>