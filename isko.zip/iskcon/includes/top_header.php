  <?php 
    session_start();
    $user_name=ucfirst($_SESSION['user_name']);
    $sid=$_SESSION['sid'];
    if($sid==''){
      header('location:index.php');
     }
    ?>
    <style>
        .navbar-header{background-color: orange; padding-right :88.28%; }
        
        .navbar-right{background-color :orange;}
    </style>
   
   <div class="navbar-header">
        <a class="navbar-brand" href="#" style="color:green">Admin</a>
    </div>

    <!-- /.navbar-header -->
    <ul class="nav navbar-top-links navbar-right">
        <!-- /.dropdown -->
        <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                <i class="fa fa-user fa-fw"></i><i class="fa fa-caret-down"></i>
            </a>
            <ul class="dropdown-menu dropdown-user">
                <li><a href="#"><i></i><?php echo 'Mr. '. $user_name;?></a>
                </li>
                
                <li class="divider"></li>
                <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                </li>
            </ul>
            <!-- /.dropdown-user -->
        </li>
        <!-- /.dropdown -->
    </ul>