<?php 


$db_host='localhost';
$username='root';
$password='root';
$dbname='iskcon_dev';
try
{
    $database = new PDO("mysql:host=$db_host;dbname=$dbname","$username","$password");
	// set the PDO error mode to exception
	$database->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$database->exec("set names utf8");
	$GLOBALS['db']= $database;
}
catch (PDOException $exc) 
{
  echo $exc->getMessage();
}


?>