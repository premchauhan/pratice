<?php 
include("includes/config.php");
 $id=$_GET['id'];

$select="select * from event_detail where id='$id'";
  $run = $GLOBALS['db']->prepare($select);
  $run->execute();
  $fetch_res=$run->fetch(PDO::FETCH_ASSOC); 
?>
    <div class="col-md-12">
       <div class="col-lg-12"> <label>Name</label></div>
       <div class="col-lg-12"> 
        <label class="form-control" readonly><?php echo ucwords(strtolower($fetch_res['event_name']));?></label></div>
   </div>

    <div class="col-md-12">
       <div class="col-lg-12"> <label>Description</label></div>
       <div class="col-lg-12">
       <textarea class="form-control" rows="6" readonly><?php echo $fetch_res['event_description'];?></textarea> 
   </div>
   </div>