<?php
include('database.php');
$sec=mysqli_query($link,"select * from tbl_auto_complete");
while($fetch_res=mysqli_fetch_array($sec))
{
	$result[]=$fetch_res;
}

?>
<!DOCTYPE html>
<html lang="en">
<html>
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width" />

    <link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/barfiller.css" />

	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script src="js/jquery-1.9.1.min.js" type="text/javascript"></script>
	<script src="js/jquery.barfiller.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/jquery.elevatezoom.min.js"></script>

	<!--bar filler code-->
   	<script type="text/javascript">
		$(document).ready(function(){
		  $('#demo-bar').barfiller({ barColor: '#2E5C5C' });
		  $('#demo-bar2').barfiller({ barColor: '#800000' });
		  $('#demo-bar3').barfiller({ barColor: '#800080' });
		  $('#demo-bar4').barfiller({ barColor: '#400080' });
		});
       
     ///image zoom code/////////

		$(document).ready(function () {
			$(".zoom_10").elevateZoom({
			    easing : true
			  	}); 
 
		});
		

		</script>
	
</head>
<body>

<div class="col-md-10 col-md-offset-1">  
<div class="col-lg-12"><h3>Image List</h3></div>

<div class="col-md-12">
	<div class="col-md-3">
		<p>Subject Marks progress Bars</p>
		<div id="demo-bar" class="barfiller">
			<div class="tipWrap"> <span class="tip"></span> </div> <span class="fill" data-percentage="65"></span>
		</div>
	</div>

	

	<div class="col-md-3">
		<p>Subject Marks progress Bars</p>
		<div id="demo-bar2" class="barfiller">
			<div class="tipWrap"> <span class="tip"></span> </div> <span class="fill" data-percentage="75"></span>
		</div>
	</div>
	
	<div class="col-md-3">
		<p>Subject Marks progress Bars</p>    
		<div id="demo-bar3" class="barfiller">
			<div class="tipWrap"> <span class="tip"></span> </div> <span class="fill" data-percentage="89"></span>
		</div>
	</div>

	<div class="col-md-3">
		<p>Subject Marks progress Bars</p>
		<div id="demo-bar4" class="barfiller">
			<div class="tipWrap"> <span class="tip"></span> </div> <span class="fill" data-percentage="56"></span>
		</div>
	</div>
</div>


<div class="col-md-12">

   <table class="table table-bordered">
   	<tr><td align="right" colspan="9"><a href=test.php>Add Regestration</a></td></tr>
  <thead>
 	<tr>
 		<th>Name</th>
 		<th>Image</th>
 		<th>State</th>
 		<th>Auto complete No.</th>
 		<th>Hindi Marks</th>
 		<th>English Marks</th>
 		<th>Science Marks</th>
 		<th>Mathes Marks</th>
 	</tr>
 </thead>
 	<?php 
	foreach($result as $value)
   	{
   		 $imagePath = 'images/'.$value['image'];
     	echo "<tr>";
      			echo "<td>".$value['name']."</td>";
                echo '<td>
                		<img style="border:1px solid #e8e8e6;" class="zoom_10" src="'.$imagePath.'" data-zoom-image="'.$imagePath.'" width="100"/>
                	</td>';
                echo "<td>".$value['state']."</td>";
                echo "<td>".$value['auto_complite']."</td>";
                echo "<td>".$value['hindi']."</td>";
                echo "<td>".$value['english']."</td>";
                echo "<td>".$value['science']."</td>";
                echo "<td>".$value['mathes']."</td>";
      	echo "</tr>";
    }
 	?>

 	
  </table>




</div>
</div>

</body>
</html>
