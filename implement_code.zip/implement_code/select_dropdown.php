<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="jquery/jquery.min.js"></script>
  <script src="jquery/bootstrap.min.js"></script>
</head>
<body>
<body background='vodting_open_now.jpg'>
<form action="database.php" method="post">
<div class="container">
  <h2></h2>
  <p><strong></strong><strong></strong></p>
  <div class="panel-group" id="accordion">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">Most Trusted Company Award (International)</a>
        </h4>
      </div>
      <div id="collapse1" class="panel-collapse collapse in">
        
		 <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse1">
           <input type="radio" name="most_trusted_company" value="Static Control"/>Static Control
		   </label>
		  </div>
         <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse1"><input type="radio" name="most_trusted_company" value="Uninet"/>Uninet </label>
		  </div>
          <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse1">
           <input type="radio" name="most_trusted_company" value="Print-Rite"/>Print-Rite
		   </label>
		  </div>
		  <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse1">
           <input type="radio" name="most_trusted_company" value="Top-Jet"/>Top-Jet
		   </label>
		  </div>
          <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse1">
           <input type="radio" name="most_trusted_company" value="Zhuhai Fast Image Products Co. Ltd."/>Zhuhai Fast Image Products Co. Ltd.
		   </label>
		  </div>
          <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse1">
           <input type="radio" name="most_trusted_company" value="Retech"/>Retech
        </label>
		  </div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">Quality Leader Award (International)</a>
        </h4>
      </div>
      <div id="collapse2" class="panel-collapse collapse">
      <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse2">
           <input type="radio" name="Quality_leader_award" value="MITSUBHISU"/>MITSUBHISU
		    </label>
		  </div>
         <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse2">
           <input type="radio" name="Quality_leader_award" value="Uninet"/>Uninet
		    </label>
		  </div>
          <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse2">
           <input type="radio" name="Quality_leader_award" value="Apex"/>Apex
		    </label>
		  </div>
		  <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse2">
           <input type="radio" name="Quality_leader_award" value="NineStar"/>Ninestar
		    </label>
		  </div>
          <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse2">
           <input type="radio" name="Quality_leader_award" value="MK Imaging"/>MK Imaging
		    </label>
		  </div>
          <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse2">
           <input type="radio" name="Quality_leader_award" value="Zhuhai Fast Image Products Co. Ltd."/>Zhuhai Fast Image Products Co. Ltd.
		    </label>
		  </div>
		  <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse2">
           <input type="radio" name="Quality_leader_award" value="Golden Green"/>Golden Green
         </label>
		  </div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">Best Retail Brand (International) Cartridge</a>
        </h4>
      </div>
      <div id="collapse3" class="panel-collapse collapse">
        <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse3">
           <input type="radio"  name="Best_Retail_Brand" value="Printer Mayin"/>Printer Mayin
		   </label>
		  </div>
           <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse3">
           <input type="radio"  name="Best_Retail_Brand" value="Cartridge World"/>Cartridge World
		   </label>
		  </div>
           <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse3">
           <input type="radio"  name="Best_Retail_Brand" value="Retech"/>Retech
		   </label>
		  </div>
		   <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse3">
           <input type="radio"  name="Best_Retail_Brand" value="Print king"/>Print king
        </label>
		  </div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse4">Best Innovative Product (International)</a>
        </h4>
      </div>
      <div id="collapse4" class="panel-collapse collapse">
        <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse4">
           <input type="radio" name="Best_Innovative_Product" value="Orink"/>Orink
		   </label>
		  </div>
          <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse4">
           <input type="radio" name="Best_Innovative_Product" value="Uninet"/>Uninet
		   </label>
		  </div>
          <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse4">
           <input type="radio" name="Best_Innovative_Product" value="MK Imaging"/>MK Imaging
		   </label>
		  </div>
		 <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse4">
           <input type="radio" name="Best_Innovative_Product" value="Apex"/>Apex
       </label>
		  </div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse5">Best 3D printing solution Provider </a>
        </h4>
      </div>
      <div id="collapse5" class="panel-collapse collapse">
        <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse5">
           <input type="radio" name="Best_3D_Printing" value="Print Rite"/>Print Rite
		   </label>
		  </div>
		  <div class="radio">
           <label data-toggle="collapse" data-target="#collapse5">
           <input type="radio" name="Best_3D_Printing" value="Chinamate"/>Chinamate
		   </label>
		  </div>
		  <div class="radio">
           <label data-toggle="collapse" data-target="#collapse5">
           <input type="radio" name="Best_3D_Printing" value="NITNU"/>NITNU
		   </label>
		  </div>
		  <div class="radio">
		   <label data-toggle="collapse" data-target="#collapse5">
           <input type="radio" name="Best_3D_Printing" value="Monotech"/>Monotech
        </label>
		  </div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse6">Best OPC Drum (International)</a>
        </h4>
      </div>
      <div id="collapse6" class="panel-collapse collapse">
        <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse6">
           <input type="radio" name="Best_Opc_Drum" value="Hamp"/>Hamp
		   </label>
		  </div>
          <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse6">
           <input type="radio" name="Best_Opc_Drum" value="Green Rich"/>Green Rich
		   </label>
		  </div>
          <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse6">
           <input type="radio" name="Best_Opc_Drum" value="Golden Green"/>Golden Green
		   </label>
		  </div>
		 <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse6">
           <input type="radio" name="Best_Opc_Drum" value="FUIJI"/>FUIJI
        </label>
		  </div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse7">Best ink solution provider (International)</a>
        </h4>
      </div>
      <div id="collapse7" class="panel-collapse collapse">
         <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse7">
           <input type="radio" name="Best_Ink_Solution" value="Inktec"/>Inktec
		     </label>
		  </div>
          <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse7">
           <input type="radio" name="Best_Ink_Solution" value="LYSON"/>LYSON
		     </label>
		  </div>
          <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse7">
           <input type="radio" name="Best_Ink_Solution" value="Inkmate"/>Inkmate
		     </label>
		  </div>
		 <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse7">
           <input type="radio" name="Best_Ink_Solution" value="Stylo"/>Stylo
		     </label>
		  </div>
		  <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse7">
           <input type="radio" name="Best_Ink_Solution" value="OPC Jet"/>OPC Jet
		     </label>
		  </div>
          <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse7">
           <input type="radio" name="Best_Ink_Solution" value="Star Ink"/>Star Ink
		     </label>
		  </div>
          <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse7">
           <input type="radio" name="Best_Ink_Solution" value="Ink Bank"/>Ink Bank
          </label>
		  </div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse8">Best Toner brand of the year</a>
        </h4>
      </div>
      <div id="collapse8" class="panel-collapse collapse">
        <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse8">
           <input type="radio" name="Best_Toner_Brand" value="TTI"/>TTI
		   </label>
		  </div>
          <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse8">
           <input type="radio" name="Best_Toner_Brand" value="ITDL"/>ITDL
		   </label>
		  </div>
         <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse8">
           <input type="radio" name="Best_Toner_Brand" value="POLYTON"/>POLYTON
		   </label>
		  </div>
		 <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse8">
           <input type="radio" name="Best_Toner_Brand" value="JADI"/>Jadi
		   </label>
		  </div>
		  <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse8">
           <input type="radio" name="Best_Toner_Brand" value="Static"/>Static
		   </label>
		  </div>
          <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse8">
           <input type="radio" name="Best_Toner_Brand" value="PTDL"/>PTDL
		   </label>
		  </div>
		  <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse8">
           <input type="radio" name="Best_Toner_Brand" value="Teshile"/>Teshile
		   </label>
		  </div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse9">Fastest Growing Indian Imaging Company</a>
        </h4>
      </div>
      <div id="collapse9" class="panel-collapse collapse">
         <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse9">
           <input type="radio" name="Fastest_Growing_Indian" value="Prodot"/>Prodot
		    </label>
		  </div>
          <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse9">
           <input type="radio" name="Fastest_Growing_Indian" value="Jet-Tec"/>Jet-Tec
		    </label>
		  </div>
           <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse9">
           <input type="radio" name="Fastest_Growing_Indian" value="INDRAYANI SALES PVT LTD"/>INDRAYANI SALES PVT LTD
		    </label>
		  </div>
		   <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse9">
           <input type="radio" name="Fastest_Growing_Indian" value="DELHI COPIER"/>DELHI COPIER
		    </label>
		  </div>
		   <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse9">
           <input type="radio" name="Fastest_Growing_Indian" value="Shree technologies"/>Shree technologies
		    </label>
		  </div>
           <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse9">
           <input type="radio" name="Fastest_Growing_Indian" value="Indigo Prints Smart Pvt. Ltd."/>Indigo Prints Smart Pvt. Ltd.
		    </label>
		  </div>
           <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse9">
           <input type="radio" name="Fastest_Growing_Indian" value="Aryan"/>Aryan
		    </label>
		  </div>
		   <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse9">
           <input type="radio" name="Fastest_Growing_Indian" value="Jet Technologies"/>Jet Technologies
		    </label>
		  </div>
		   <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse9">
           <input type="radio" name="Fastest_Growing_Indian" value="Image King"/>Image King
		    </label>
		  </div>
           <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse9">
           <input type="radio" name="Fastest_Growing_Indian" value="Sumangalam"/>Sumangalam
		    </label>
		  </div>
		   <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse9">
           <input type="radio" name="Fastest_Growing_Indian" value="HCR"/>HCR
		    </label>
		  </div>
        
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse10">Best Customer Support (India)</a>
        </h4>
      </div>
      <div id="collapse10" class="panel-collapse collapse">
         <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse10">
           <input type="radio" name="Best_Customer_Support" value="Jet Cartridge"/>Jet Cartridge
		     </label>
		  </div>
          <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse10">
           <input type="radio" name="Best_Customer_Support" value="Sumangalam"/>Sumangalam
		     </label>
		  </div>
           <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse10">
           <input type="radio" name="Best_Customer_Support" value="Prodot"/>Prodot
		     </label>
		  </div>
		   <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse10">
           <input type="radio" name="Best_Customer_Support" value="Jet-Tec"/>Jet-Tec
		     </label>
		  </div>
		 <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse10">
           <input type="radio" name="Best_Customer_Support" value="Indigo"/>Indigo
		     </label>
		  </div>
           <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse10">
           <input type="radio" name="Best_Customer_Support" value="Alphabet"/>Alphabet
		     </label>
		  </div>
           <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse10">
           <input type="radio" name="Best_Customer_Support" value="Axel Technology"/>Axel Technology
		     </label>
		  </div>
		  <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse10">
           <input type="radio" name="Best_Customer_Support" value="INDRAYANI SALES PVT LTD"/>INDRAYANI SALES PVT LTD
		     </label>
		  </div>
		   <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse10">
           <input type="radio" name="Best_Customer_Support" value="Globe Technology"/>Globe Technology
		     </label>
		  </div>
		  <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse10">
           <input type="radio" name="Best_Customer_Support" value="HCR"/>HCR
		     </label>
		  </div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse11">Best Young Entrepreneur of the year (India)</a>
        </h4>
      </div>
      <div id="collapse11" class="panel-collapse collapse">
       
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse12">Best Solution Provider (India)</a>
        </h4>
      </div>
      <div id="collapse12" class="panel-collapse collapse">
        <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse12">
           <input type="radio" name="Best_Solution_Provider" value="Sumanglam"/>Sumangalam
		  </label>
		  </div>
          <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse12">
           <input type="radio" name="Best_Solution_Provider" value="Prodot"/>Prodot
		   </label>
		  </div>
          <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse12">
           <input type="radio" name="Best_Solution_Provider" value="Jet-Tec"/>Jet-Tec
		   </label>
		  </div>
		  <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse12">
           <input type="radio" name="Best_Solution_Provider" value="Indigo"/>Indigo
		   </label>
		  </div>
		  <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse12">
           <input type="radio" name="Best_Solution_Provider" value="ASHISH ELECTRONICS (BANGALORE)"/>ASHISH ELECTRONICS (BANGALORE)
		   </label>
		  </div>
          <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse12">
           <input type="radio" name="Best_Solution_Provider" value="Power Point Cartridges"/>Power Point Cartridges
		   </label>
		  </div>
          <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse12">
           <input type="radio" name="Best_Solution_Provider" value="Globe Technology"/>Globe Technology
		   </label>
		  </div>
		  <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse12">
           <input type="radio" name="Best_Solution_Provider" value="Shree technologies"/>Shree technologies
		   </label>
		  </div>
		  <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse12">
           <input type="radio" name="Best_Solution_Provider" value="Patel traders"/>Patel traders
		   </label>
		  </div>
		  <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse12">
           <input type="radio" name="Best_Solution_Provider" value="Jet Technology"/>Jet Technology
		   </label>
		  </div>
		  <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse12">
           <input type="radio" name="Best_Solution_Provider" value="Jet Cartridge"/>Jet Cartridge
		   </label>
		  </div>
		  <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse12">
           <input type="radio" name="Best_Solution_Provider" value="Print-it"/>Print-it
		   </label>
		  </div>
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse13">Young Generation Award (India)</a>
        </h4>
      </div>
      <div id="collapse13" class="panel-collapse collapse">
       
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse14">Lifetime Achievement Award (India)</a>
        </h4>
      </div>
      <div id="collapse14" class="panel-collapse collapse">
       
        
    
      </div>
    </div>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse15">Best Indian Distributor</a>
        </h4>
      </div>
      <div id="collapse15" class="panel-collapse collapse">
       <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse15">
          <input type="radio" name="Best_Indian_Distributor" value="Prodot"/>Prodot
		  </label>
		  </div>
		  <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse15">
          <input type="radio" name="Best_Indian_Distributor" value="Jet-Tec"/>Jet-Tec
		  </label>
		  </div>
		  <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse15">
          <input type="radio" name="Best_Indian_Distributor" value="Sumangalam"/>Sumangalam
		  </label>
		  </div>
		  <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse15">
		  <input type="radio" name="Best_Indian_Distributor" value="Image-King"/>Image-King
		  </label>
		  </div>
		  <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse15">
		  <input type="radio" name="Best_Indian_Distributor" value="LASER TECHNOLOGIES (AHD)"/>LASER TECHNOLOGIES (AHD)
		  </label>
		  </div>
		  <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse15">
          <input type="radio" name="Best_Indian_Distributor" value="Formujet"/>Formujet
		  </label>
		  </div>
		  <div class="radio">
	    <label data-toggle="collapse" data-target="#collapse15">
          <input type="radio" name="Best_Indian_Distributor" value="Dubaria"/>Dubaria
		  </label>
		  </div> 
      </div>
    </div>
  </div> 
  <button type="submit" class="btn btn-primary btn-lg btn-block" name="submit">SUBMIT</button>
</div>
  </form>  
</body>
</html>
