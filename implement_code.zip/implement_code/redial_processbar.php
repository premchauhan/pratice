<!doctype html>
<html>
<head>
<meta charset="utf-8">

        <title>jQuery Radial Progress Bar Plugin Examples</title>
        <link rel="stylesheet" href="css/examples.css">
    </head>
    <body>
    <h1 style="margin:15px auto  auto; text-align:left">jQuery Radial Progress Bar Examples</h1>
        <section>
          <div id="example1" class="example"></div>
      </section>
        <script src="js/jquery-1.12.1.min.js"></script>
        <script src="js/radial-progress-bar.js"></script>
        <script src="js/examples.js"></script>
    </body>
</html>
