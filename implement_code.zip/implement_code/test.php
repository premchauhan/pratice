<?php 
error_reporting(0);
include('database.php');

if(isset($_REQUEST['submit']))
{

$name=$_POST['name'];

$image_name = $_FILES['image']['name'];
$tmp_name   = $_FILES['image']['tmp_name'];
move_uploaded_file($tmp_name,'images/'.$image_name);

$state=implode(',',$_POST['state']);
$auto_complite=$_POST['auto_complite'];
$hindi=$_POST['hindi'];
$english=$_POST['english'];
$science=$_POST['science'];
$mathes=$_POST['mathes'];

$insert=mysqli_query($link,"insert into tbl_auto_complete set
	                                             name='".$name."',
	                                             image='".$image_name."',
	                                             state='".$state."',
	                                             auto_complite='".$auto_complite."',
	                                             hindi='".$hindi."',
	                                             english='".$english."',
	                                             science='".$science."',
	                                             mathes='".$mathes."'");

if($insert){$msg='Record inserted successfuly'; header("location:test_list.php?msg=$msg");}else{echo 'Record not Inserted';}

}

?>
<!DOCTYPE html>
<html>
<head>



		<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
		<link href="css/bootstrap-multiselect.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="js/jquery.min.js"></script> 
		<script type="application/javascript" src="js/MSelectDBox.js"></script>
         
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/bootstrap-filestyle.min.js"> </script>
		<script src="js/bootstrap-multiselect.js" type="text/javascript"></script>


<!--multiselect check box code -->
<script type="text/javascript">
    $(function () {
        $('#lstFruits').multiselect({
            numberDisplayed: 3,
            includeSelectAllOption: false,
        });
    });
</script>
<!--auto complete code -->
<script type="application/javascript">
	$(document).ready(function(){

		$.prototype.mSelectDBox.prototype._globalStyles[".m-select-d-box__list-item_selected"]["background-color"] = "mediumseagreen";
		$.prototype.mSelectDBox.prototype._globalStyles[".m-select-d-box__list-item_selected:hover, .m-select-d-box__list-item_selected.m-select-d-box__list-item_hover"]["background-color"] = "green";
		$.prototype.mSelectDBox.prototype._globalStyles[".m-select-d-box__list-item:active, .m-select-d-box__list-item_selected:active"]["background-color"] = "darkgreen";


		$("#barcode").mSelectDBox({
			"list": (function(){ 
							var arr = []; 
							for(var c=0; c<900; c++){ arr.push(c); }
							return arr; 
						})(),
			"multiple": false,
			"autoComplete": true,
		});
});
</script>

<script>
function remove_error(field_name){
	$("#"+ field_name).html('');
}

function save_value()
{
	var name=$("#name").val();
	var image=$("#image").val();
  var state=$("#lstFruits").val();
  var auto_complite=$("#auto_complite").val();
  var hindi=$("#hindi").val();
  var english=$("#english").val();
  var science=$("#science").val();
  var mathes=$("#mathes").val();
   
    //alert(state);

	var counter=1;
    if(name==''){ counter=0; $("#error_name").html('Please Fill name');}
    if(image==''){counter=0; $("#error_image").html('Please Choose Image');}

    //console.log('====',state);
    
             if(state=='' || state == null){counter=0; $("#error_state").html('Please Select State');}
    
             if(auto_complite==''){counter=0; $("#error_auto_complite").html('Please Select auto complite No.');}
   
             if(hindi==''){counter=0; $("#error_hindi").html('Please Fill Hindi marks');}
             if(english==''){counter=0; $("#error_english").html('Please Fill English marks');}
             if(science==''){counter=0; $("#error_science").html('Please Fill Science marks');}
             if(mathes==''){counter=0; $("#error_mathes").html('Please Fill Mathes marks');}

        
          if(counter==1){return true;}else{return false;}
}
</script>
<style>
.col-md-2{
  margin:3px;
}
</style>
</head>
<body>
<form action="test.php" method="post" onsubmit="return save_value()" enctype="multipart/form-data" class="form-horizontal">

	<div class="form-group">
       <div class="col-md-2" class="form-control"><label>Name</label></div>
       <div class="col-md-2">
        <input type="text" name="name" id="name" onclick="remove_error('error_name');" class="form-control">
           <div id="error_name" style="color:red"></div>
       </div>
    </div>

	<div class="form-group">
       <div class="col-md-2" class="form-control"><label>Image</label></div>
       <div class="col-md-2">
        <input type="file" name="image" id="image" onclick="remove_error('error_image');" class="filestyle" data-icon="false">
          <div id="error_image" style="color:red"></div>
       </div>
    </div>


	<div class="form-group">
<div class="col-md-2" class="form-control"><label>State</label></div>
   <div class="col-md-5">
    <select id="lstFruits" multiple="multiple"   onchange="remove_error('error_state');" name="state[]" >
        <option value="AK">Alaska</option>
        <option value="AZ">Arizona</option>
        <option value="AR">Arkansas</option>
        <option value="CA">California</option>
        <option value="CO">Colorado</option>
        <option value="OR">Oregon</option>
        <option value="PA">Pennsylvania</option>
        <option value="RI">Rhode Island</option>
        <option value="SC">South Carolina</option>
        <option value="WV">West Virginia</option>
        <option value="WI">Wisconsin</option>
        <option value="WY">Wyoming</option>
    </select>
     <div id="error_state" style="color:red"></div>
  </div>
</div>


<div class="form-group">
       <div class="col-md-2" class="form-control"><label>Enter a number</label></div>
       <div class="col-md-2">
        <input  name="auto_complite" class="std-input" id="auto_complite" onclick="remove_error('error_auto_complite');"   type="text">
        <div id="error_auto_complite" style="color:red"></div>
       </div>
    </div>

    <div class="form-group">
       <div class="col-md-2" class="form-control"><label>Hindi Marks</label></div>
       <div class="col-md-2">
        <input type="text" name="hindi" id="hindi" onclick="remove_error('error_hindi');" class="control_form">
           <div id="error_hindi" style="color:red"></div>
       </div>
    </div>

    <div class="form-group">
       <div class="col-md-2" class="form-control"><label>English Marks</label></div>
       <div class="col-md-2">
        <input type="text" name="english" id="english" onclick="remove_error('error_english');" class="control_form">
         <div id="error_english" style="color:red"></div>
       </div>
    </div>

    <div class="form-group">
       <div class="col-md-2" class="form-control"><label>Science Marks</label></div>
       <div class="col-md-2">
        <input type="text" name="science" id="science" onclick="remove_error('error_science');"  class="control_form">
           <div id="error_science" style="color:red"></div>
       </div>
    </div>

    <div class="form-group">
       <div class="col-md-2" class="form-control"><label>Math Marks</label></div>
       <div class="col-md-2">
        <input type="text" name="mathes" id="mathes" onclick="remove_error('error_mathes');" class="control_form">
          <div id="error_mathes" style="color:red"></div>
       </div>
    </div>

<div class="form-group"> 
   <div class="col-lg-offset-2 col-lg-10">
     <button type="submit" name="submit"  class="btn btn-default">Submit</button>
   </div>
</div>
</form>
</body>
</html>



