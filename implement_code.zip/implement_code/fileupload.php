<!DOCTYPE html>
<html>
<head>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" >
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js" ></script>
    <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap-filestyle.min.js"> </script>
    
</head>

<body>
<div class="container">
    <h2>Bootstrap File upload demo</h2>
    
    <div class="col-xs-4">
       
        <div class="form-group">
            <label class="control-label">A file upload button without icon</label>
            <input type="file" class="filestyle" data-icon="false">
        </div>
    </div>

     <div class="col-xs-4">
         <div class="form-group">
            <label class="control-label">A file upload button without icon</label>
            <input type="file" class="filestyle" data-buttonText="Select a File">
        </div>
    </div>


    <div class="col-xs-4">
         <div class="form-group">
            <label class="control-label">A file upload button without icon</label>
            <input type="file" class="filestyle " data-buttonText="Open">
        </div>
    </div>



    </div>
</body>
</html>