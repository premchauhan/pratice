<!doctype html>
<html>
<head>

<script src="js/jquery.min.js"></script>
<script type="application/javascript" src="js/MSelectDBox.js"></script>
<script type="application/javascript">
	$(document).ready(function(){

		$.prototype.mSelectDBox.prototype._globalStyles[".m-select-d-box__list-item_selected"]["background-color"] = "mediumseagreen";
		$.prototype.mSelectDBox.prototype._globalStyles[".m-select-d-box__list-item_selected:hover, .m-select-d-box__list-item_selected.m-select-d-box__list-item_hover"]["background-color"] = "green";
		$.prototype.mSelectDBox.prototype._globalStyles[".m-select-d-box__list-item:active, .m-select-d-box__list-item_selected:active"]["background-color"] = "darkgreen";


		$("#barcode").mSelectDBox({
			"list": (function(){ 
							var arr = []; 
							for(var c=0; c<900; c++)
								{ 
									arr.push(c); 
								}
							return arr; 
						})(),
			"multiple": false,
			"autoComplete": true,
		});



	});
</script>


</head>
<body>
	<h3>A demo of auto complete</h3>
	<label>Enter a number: <input id="barcode" class="std-input" type="text"> </label>
</body>
</html>

