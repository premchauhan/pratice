<!DOCTYPE html>
<html lang="en">
<html>
<head>
   <link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/barfiller.css" />
	<link href="css/bootstrap-multiselect.css" rel="stylesheet" type="text/css" />

	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script src="js/jquery-1.9.1.min.js" type="text/javascript"></script>
	<script src="js/jquery.barfiller.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/jquery.elevatezoom.min.js"></script>
	<script src="js/bootstrap-multiselect.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="application/javascript" src="js/MSelectDBox.js"></script>

     <!--barfiller code-->
	<script>
	$(document).ready(function (){
		$("#english").barfiller({ color:"red"});
		$("#hindi").barfiller({ color:"green"});
	})
	</script>

<!--image zoom -->
	<script>
	$(document).ready(function (){
     $("#image").elevateZoom({
      ///remove it not iffect//easing:true,
     });

	});
	</script>

<!--multiselect checkbox-->
<script>
$(function(){
	$("#country").multiselect({
		//no effeect its remove//numberDisplayed:3,
		//no effect/includeSelectAlloption:false,

	});

});

</script>

<!--auto complete no code-->
<script type="application/javascript">
$(document).ready(function(){

		$.prototype.mSelectDBox.prototype._globalStyles[".m-select-d-box__list-item_selected"]["background-color"] = "mediumseagreen";
		$.prototype.mSelectDBox.prototype._globalStyles[".m-select-d-box__list-item_selected:hover, .m-select-d-box__list-item_selected.m-select-d-box__list-item_hover"]["background-color"] = "green";
		$.prototype.mSelectDBox.prototype._globalStyles[".m-select-d-box__list-item:active, .m-select-d-box__list-item_selected:active"]["background-color"] = "darkgreen";


	$("#number").mSelectDBox({
			"list": (function(){ 
							var array = []; 
							for(var a=100; a<5000; a++)
								{ 
									array.push(a); 
								}
							return array; 
						})(),
		//no effect	"multiple": false,
			//no effect "autoComplete": true,
		});



	});
</script>
</head>
<body>
<form action="" method="post" class="form-horizontal">
  
  <div class="col-md-4">
     	<p> Barfiller Hindi marks </p>
     	<div id="hindi" class="barfiller">
     		<div class="tipWrap"><span class="tip"></span></div><span class="fill" data-percentage="68"></span>
     	</div>

	<div class="col-md-4">
		<p>Barfiller English marks</p>
		<div id="english" class="barfiller">
			<div><span class="tip"></span></div><span class="fill" data-percentage="75"></span>
		</div>
	</div>

     

<div class="form-group">
	<div class="col-md-2">Image</div>
	<div class="col-md-2">
		<image src="images/1.jpg" id="image" data-zoom-image="images/1.jpg" width="121">
	</div>
</div>


<div class="form-group">
	<div class="col-md-4">Country</div>
	<div class="col-md-2">
	<select name="country" id="country" multiple="multiple">
    <option value="in">India</option>
    <option value="pak">Pakastan</option>
    <option value="am">America</option>
    <option value="ne">Nepal</option>
    <option value="jap">Japan</option>
	</select>
	</div>
</div>

<div class="form-group">
	<div class="col-md-4">Auto Complete No.</div>
	<div class="col-md-2">
		<input type="text"  name="number" id="number">
	</div>
</div>

</form>

</body>
</html>