<?php 
if(isset($_REQUEST['submit'])){
$state=$_POST['state'];
echo $state;

echo '<pre>';
print_r($_POST);
echo '</pre>';
}
?>

<!DOCTYPE html>
<html>
<head>

<script type="text/javascript" src="js/jquery.min.js"></script>    

<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/bootstrap.min.js"></script>

<link href="css/bootstrap-multiselect.css" rel="stylesheet" type="text/css" />
<script src="js/bootstrap-multiselect.js" type="text/javascript"></script>

<!--
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<link href="http://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.0.3/js/bootstrap.min.js"></script>
<link href="http://cdn.rawgit.com/davidstutz/bootstrap-multiselect/master/dist/css/bootstrap-multiselect.css" rel="stylesheet" type="text/css" />
<script src="http://cdn.rawgit.com/davidstutz/bootstrap-multiselect/master/dist/js/bootstrap-multiselect.js" type="text/javascript"></script>
-->

<script type="text/javascript">
    $(function () {
        $('#lstFruits').multiselect({
            numberDisplayed: 3,
            includeSelectAllOption: false,
        });
    });
</script>
	
</head>
<style>
.btn btn-default{
    margin-top:10px;
}
</style>
<body>


<form action="multiple_select.php" method="post">
<h2>A demo of using multi-select with checkboxes</h2>
<div class="form-group">
<div class="col-md-2" class="form-control"><label>State</label></div>
   <div class="col-md-5">
    <select id="lstFruits" multiple="multiple" name="state[]" >
        <option value="AK">Alaska</option>
        <option value="AZ">Arizona</option>
        <option value="AR">Arkansas</option>
        <option value="CA">California</option>
        <option value="CO">Colorado</option>
        <option value="OR">Oregon</option>
        <option value="PA">Pennsylvania</option>
        <option value="RI">Rhode Island</option>
        <option value="SC">South Carolina</option>
        <option value="WV">West Virginia</option>
        <option value="WI">Wisconsin</option>
        <option value="WY">Wyoming</option>
    </select>
  </div>
</div>

<div class="form-group"> 
   <div class="col-lg-offset-2 col-lg-10">
     <button type="submit" name="submit"  class="btn btn-default">Submit</button>
   </div>
</div>
</form>
</body>
</html>
