<!doctype html>
<html>
<head>
    <link rel="stylesheet" href="css/zoom.css">
    <link rel="stylesheet" href="css/jzoom/cv.css">
    <link rel="stylesheet" href="css/jzoom/demo.css">
    <script src="https://cdn.bootcss.com/jquery/2.2.0/jquery.min.js"></script>
    <script src="js/zoom.js"></script>

</head>

<body>

    <section class="page" id="page3">
        <h2>A demo of magnifying images</h2>
        <div class="row">
            <div class="cell">
                <div id="magnify-demo">
                    <img src="images/1.jpg" height="250" width="250"> </div>
            </div>
        </div>
    </section>


    
    <script>
        $('#magnify-demo').zoom();
    </script>
</body>
</html>

