<!DOCTYPE html>
<html>
<head>
	<script src="http://code.jquery.com/jquery-1.9.1.min.js" type="text/javascript"></script>

	<link rel="stylesheet" type="text/css" href="css/barfiller.css" />
    <script src="js/jquery.barfiller.js" type="text/javascript"></script>
	
	<!--
		<link rel="stylesheet" type="text/css" href="css/barfiller/style.css" />
		<script src="js/barfiller/jquery.barfiller.js" type="text/javascript"></script>
	-->

	<script type="text/javascript">
		$(document).ready(function(){
		  $('#demo-bar').barfiller({ barColor: '#2E5C5C' });
		  $('#demo-bar2').barfiller({ barColor: '#800000' });
		  $('#demo-bar3').barfiller({ barColor: '#800080' });
		  $('#demo-bar4').barfiller({ barColor: '#400080' });
		  $('#demo-bar5').barfiller({ barColor: '#004040' });
		});

	</script>

</head>
<body>

<h1>Barfiller</h1>

	<p>A demo of animated progress Bars</p>

	<div id="demo-bar" class="barfiller">
	    <div class="tipWrap"> <span class="tip"></span> </div> <span class="fill" data-percentage="90"></span>
	</div>
	<div id="demo-bar2" class="barfiller">
	    <div class="tipWrap"> <span class="tip"></span> </div> <span class="fill" data-percentage="60"></span>
	</div>    
	<div id="demo-bar3" class="barfiller">
	    <div class="tipWrap"> <span class="tip"></span> </div> <span class="fill" data-percentage="80"></span>
	</div>   
	<div id="demo-bar4" class="barfiller">
	    <div class="tipWrap"> <span class="tip"></span> </div> <span class="fill" data-percentage="20"></span>
	</div>   
	<div id="demo-bar5" class="barfiller">
	    <div class="tipWrap"> <span class="tip"></span> </div> <span class="fill" data-percentage="75"></span>
	</div>               
	
</div>
 



</body>
</html>