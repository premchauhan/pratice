<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="http://code.jquery.com/jquery-1.10.1.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> 


<style>
.nav-tabs{ border-color:#B12926; width:60%; }
  

.nav-tabs > li a { border: 1px solid #B12926;background-color:#B12926; color:#fff; border-top-left-radius: 10px;border-top-right-radius: 10px;}

.nav-tabs > li.active > a,
.nav-tabs > li.active > a:focus,
.nav-tabs > li.active > a:hover
   {background-color:#F9E0DF; color:#000; border: 1px solid #B12926; border-bottom-color: transparent;
    border-top-left-radius: 10px; border-top-right-radius: 10px;
   }
  
.nav-tabs > li > a:hover
{background-color: #F9E0DF !important; border-radius: 5px; color:#000; border-top-left-radius: 10px;
    border-top-right-radius: 10px;    
} 

.tab-pane{border:solid 1px #B12926; border-top: 0; width:60%; background-color:#F9E0DF;padding:5px;}


</style>
</head>

<body>
<div class="container">
<h3>A demo to load data from MysQL DB in Bootstrap Tab by $.post</h3>

<!-- Nav tabs -->
<ul class="nav nav-tabs" role="tablist">
  <li class="active" ><a href="#hometab" role="tab" data-toggle="tab">Home</a></li>
  <li><a href="#reviews" role="tab" data-toggle="tab">Reviews</a></li>
  <li><a href="#featurestab" role="tab" data-toggle="tab">Features</a></li>
  <li><a href="#products" role="tab" data-toggle="tab">Products</a></li>
  
</ul>
</li>

<!-- Tab panes -->
<div class="tab-content">
  <div class="tab-pane active" id="hometab">Write something for home tab</div>
  <div class="tab-pane" id="reviews">Reviews Tab / Add reviews here</div>
  <div class="tab-pane" id="featurestab">Present features here</div>
  <div class="tab-pane" id="products"> <button type="button" class="btn btn-danger active" id="loaddata">Load Products Data</button></div>
    
</div>

</body>
</html>

