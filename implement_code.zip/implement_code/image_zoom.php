<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width" />
<title>
</title>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.elevatezoom.min.js"></script>
</head> 
<script type="text/javascript">
$(document).ready(function () {
    $("#zoom_10").elevateZoom({
        //zoomWindowHeight:190, //height set for small image size then use
        //zoomWindowWidth:255,
    	//scrollZoom : true,
        easing : true
	  	}); 

});

</script>      
     <!--images (27).jpg-->
<div class="zoom-left">
    <img style="border:1px solid #e8e8e6;" width="125" id="zoom_10" src="images/1.jpg" 
    data-zoom-image="images/1.jpg" width="311"/>
  </div>